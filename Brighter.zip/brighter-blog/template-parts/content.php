<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Brighter_Blog
 */
?>
<div class="col-12 single-post-item">
    <article id="post-<?php the_ID(); ?>" class="post-details blog-single">
        <div class="post-img blog-img video-wrap2">
            <?php
            $thumbnail_id = get_post_thumbnail_id(get_the_ID());
            if (get_the_post_thumbnail_url()) {
                $alt_text = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
            } else {
                $alt_text = 'No Image';
            }
            if (get_the_post_thumbnail_url()) {
                // Get the post thumbnail ID
                ?>
                <img src="<?php the_post_thumbnail_url() ?>" alt="<?php echo esc_attr($alt_text); ?>">
                <?php
            }
            // Get the post format
            $brighter_blog_post_format = get_post_format();
            if ($brighter_blog_post_format == 'gallery') {
                // Assuming you have a custom field or a method to get the gallery image URL
                $gallery_url = get_post_meta(get_the_ID(), 'image_gallery', true); // Replace with your method
                $image_urls_array = explode(',', $gallery_url);
                foreach ($image_urls_array as $urlItem) {
                    ?>
                    <a href="<?php echo esc_url($urlItem); ?>" class="popup-image icon-btn">
                        <i class="far fa-images"></i>
                    </a>
                    <?php
                }

            } elseif ($brighter_blog_post_format == 'video') {
                // Assuming you have a custom field or a method to get the video URL
                $brighter_blog_video_url = get_post_meta(get_the_ID(), 'video_url', true); // Replace with your method
                ?>
                <a href="<?php echo esc_url($brighter_blog_video_url); ?>" class="play-btn style3 popup-video">
                    <i class="fas fa-play"></i>
                </a>
                <?php
            } elseif ($brighter_blog_post_format == 'image') {
                // Assuming you have a custom field or a method to get the image URL
                $image_url = get_post_meta(get_the_ID(), 'image_url', true); // Replace with your method
                ?>
                <a href="<?php echo esc_url($image_url); ?>" class="play-btn style3 popup-image">
                    <i class="far fa-image"></i>
                </a>
                <?php
            } elseif ($brighter_blog_post_format == 'audio') {
                // Assuming you have a custom field or a method to get the audio URL
                $audio_url = get_post_meta(get_the_ID(), 'audio_url', true); // Replace with your method
                ?>
                <a href="<?php echo esc_url($audio_url); ?>" class="play-btn style3 popup-audio">
                    <i class="fa fa-headphones"></i>
                </a>
                <?php
            } elseif ($brighter_blog_post_format == 'quote') {
                // Assuming you have a custom field or a method to get the audio URL
                $quote_url = get_post_meta(get_the_ID(), 'quote_url', true); // Replace with your method
                ?>
                <a href="<?php echo esc_url($quote_url); ?>" class="play-btn style3 popup-quote">
                    <i class="fas fa-quote-right"></i>
                </a>
                <?php
            } elseif ($brighter_blog_post_format == 'link') {
                // Assuming you have a custom field or a method to get the audio URL
                $link_url = get_post_meta(get_the_ID(), 'link_url', true); // Replace with your method
                ?>
                <a href="<?php echo esc_url($link_url); ?>" class="play-btn style3 popup-link">
                    <i class="fas fa-link"></i>
                </a>
                <?php
            } else {
                // Assuming you have a custom field or a method to get the default URL
                $default_url = get_permalink(); // Replace with your method if needed
                ?>
                <a href="<?php echo esc_url($default_url); ?>" class="play-btn style3 popup-default">
                </a>
                <?php
            }
            ?>

        </div>

        <div class="post-contents with-thum-img blog-content">
            <div class="post-meta-item blog-meta">
                <?php
                // Get the author ID of the current post
                $brighter_blog_author_id = get_the_author_meta('ID');
                // Get the author's avatar URL
                $brighter_blog_author_avatar_url = get_avatar_url($brighter_blog_author_id);
                $brighter_blog_author_name = get_the_author_meta('display_name');
                ?>
                    <a href="<?php echo esc_url(get_permalink(get_option('page_for_posts'))); ?>"
                       class="blog-meta-author">
                        <img src="<?php echo esc_url($brighter_blog_author_avatar_url); ?>" alt="<?php echo esc_attr($brighter_blog_author_name); ?>">
                        <?php echo esc_html($brighter_blog_author_name); ?>
                    </a>
                    <a href="<?php the_permalink(); ?>">
                        <i class="far fa-calendar-check"></i>
                        <?php echo esc_html(get_the_date('M j Y')); ?>
                    </a>
                    <a href="<?php the_permalink(); ?>">
                        <i class="far fa-comment"></i>
                        <?php echo esc_html(get_comments_number().' ');
                            if (get_comments_number() <=1 ){
                                esc_html_e('Comment', 'brighter-blog');
                            }
                            else{
                                esc_html_e('Comments', 'brighter-blog');
                            }
                        ?>
                    </a>
                   
                    <?php
                    // Get the categories for the current post
                    $categories = get_the_category();
                    $separator = ' ';
                    $output = '';
                    if(!empty($categories)){
                    ?>
                        <a href="<?php the_permalink(); ?>">
                            <i class="fas fa-pen-fancy"></i>
                        </a>
                    <?php
                    }
                    // Check if there are any categories
                    if (!empty($categories)) {
                        $count = 0; // Initialize a counter to limit the number of categories
                        foreach ($categories as $category) {
                            // Limit the output to 4 categories
                            if ($count >= 4) {
                                break;
                            }
                            $post_catgory_link = get_category_link($category->term_id);
                            $post_category_name = $category->name;
                            ?>
                            <a class="cat-blog-pad" href="<?php echo esc_url($post_catgory_link) ?>">
                                <?php echo esc_html($post_category_name) ?> 
                            </a>
                            <?php
                            $count++;
                        }
                        // Trim the trailing separator and echo the final output
                        echo esc_html(trim($output, $separator));
                    }
                    ?>
            </div>
            <?php
            if (is_singular()) {
                ?>
                <h2 class="post-title blog-title single-blog-title">
                    <?php the_title(); ?>
                </h2>
                <div class="entry-content post-content blog-text">
                    <p>
                        <?php the_content(); ?>
                    </p>
                </div>
                <?php
            } else {
                ?>
                <h2 class="post-title blog-title single-blog-title">
                    <a href="<?php the_permalink(); ?>">
                        <?php the_title(); ?>
                    </a>
                </h2>
                <div class="post-content blog-text">
                    <p>
                        <?php the_excerpt(); ?>
                    </p>
                </div>
                <?php
            }
            ?>
            <div class="row post-button tagcloud-row">
                <div class="col-md-8 col-sm-12 tagcloud">
                    
                    <?php
                    // Fetch tags for the current post
                    $post_tags = get_the_tags(get_the_ID());
                    // Check if tags were returned and are an array
                    if (!empty($post_tags)) {
                    ?>
                    <span class="title"><?php esc_html_e('Tags:' , 'brighter-blog'); ?></span>
                    <?php
                    }
                    if ($post_tags && is_array($post_tags)) {
                        // Initialize counter
                        $tag_count = 0;
                        // Loop through each tag and create a link, but limit to 5 tags
                        foreach ($post_tags as $post_tag) {
                            // Break the loop if the counter reaches 5
                            if ($tag_count >= 6) {
                                break;
                            }
                            ?>
                            <a href="<?php echo esc_url(get_tag_link($post_tag->term_id)); ?>">
                                <?php echo esc_html($post_tag->name); ?>
                            </a>
                            <?php
                            // Increment the counter
                            $tag_count++;
                        }
                    }
                    ?>
                </div>
                <?php
                if (!is_single()) {
                    ?>
                    <div class="col-md-4 col-sm-12 continue-reading">
                        <a href="<?php the_permalink(); ?>" class="link-btn">
                            <?php esc_html_e('Continue Reading', 'brighter-blog'); ?>
                            <i class="fas fa-angle-double-right"></i>
                        </a>
                    </div>
                    <?php
                } else {
                    ?>
                    <div class="col-md-4 col-sm-12 post-share">
                        <div class="share-this-post">
                            <div class="social-btn style5">

                                <?php

                                // Call the social media share function
                                brighter_blog_custom_social_media_share();
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </article>
</div>


<br>

