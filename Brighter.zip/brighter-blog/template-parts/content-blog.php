<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Brighter_Blog
 */

?>
<!-- this is backup code  for content -->
<div class="col-12 single-post-item">
    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> class="post-single blog-card">
        <header class="entry-header">
            <div class="entry-meta">
                <?php
                // Get the author ID of the current post
                $author_id = get_the_author_meta('ID');
                // Get the author's avatar URL
                $author_avatar_url = get_avatar_url($author_id);
                $author_name = get_the_author_meta('display_name', $author_id);
                ?>
            </div><!-- .entry-meta -->
        </header><!-- .entry-header -->
        <div class="post-img blog-img video-wrap2">
            <img src="<?php brighter_blog_post_thumbnail();
             // Get the post thumbnail ID
             $thumbnail_id = get_post_thumbnail_id(get_the_ID());
             if(get_the_post_thumbnail_url()){
                 $alt_text = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
             }
             else{
                 $alt_text = 'No Image';
             }
            ?>" alt="<?php echo esc_attr($alt_text); ?>">
            <?php
            // Get the video URL from the post meta
            $brighter_blog_video_url = get_post_meta(get_the_ID(), 'video_url', true);
            if ($brighter_blog_video_url) {
                ?>
                <a href="<?php echo esc_url($brighter_blog_video_url); ?>" class="play-btn style3 popup-video"><i
                            class="fas fa-play"></i></a>
                <?php
            }
            ?>
        </div>
        <a class="post-contents with-thum-img blog-content">
            <div class="post-meta-item blog-meta">
                <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>"
                   class="blog-meta-author"><?php the_author(); ?>
                </a>
               
                    <img src="<?php echo esc_url($author_avatar_url); ?>" alt="<?php echo esc_attr($author_name); ?>" class="author-image">
                <?php
                    brighter_blog_posted_by();
                ?>
                <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>">
                    <i class="far fa-calendar-check"></i><?php brighter_blog_posted_on(); ?>
                </a>
            </div>
            <h2 class="post-title blog-title">
                <a href="<?php the_permalink(); ?>">
                    <?php the_title(); ?>
                </a>
            </h2>
                <?php
                if(is_singular()){
                    ?>
                    <h2 class="entry-title">
                        <?php the_title(); ?>
                    </h2>
                    <?php
                }
                else{
                 ?>
                 <a href="<?php the_permalink();?>">
                    <h2 class="entry-title">
                        <?php the_title(); ?>
                    </h2>
                 </a>
                 <?php
                 }
                 ?>
            <div class="post-content blog-text">
                <p>.</p>
            </div>
            <div class="post-button">
                <div class="tagcloud">
                    <?php
                    // Get the tags associated with the current post
                    $post_tags = get_the_tags();
                    // Check if tags exist for the current post
                    if ($post_tags) {
                        // Loop through each tag and output the tag with a link to the tag archive page
                        foreach ($post_tags as $post_tag) {
                            $post_tag_link = get_tag_link($post_tag->term_id);
                            $post_tag_name = $post_tag->name;
                            ?>
                            <span class="title">
                                <?php 
                                if(!empty($post_tags)){
                                    ?>
                                    Tags:
                                <?php
                                }
                                ?>
                                <a href="<?php echo esc_url($post_tag_link);?>">
                                    <?php echo esc_html($post_tag_name); ?>
                                </a>
                            </span>
                            <?php
                        }
                    }
                    ?>
                </div>
                <div class="entry-content">
                    <?php
                    the_content(
                        sprintf(
                            wp_kses(
                            /* translators: %s: Name of current post. Only visible to screen readers */
                                __('Continue reading<span class="screen-reader-text"> "%s"</span>', 'brighter-blog'),
                                array(
                                    'span' => array(
                                        'class' => array(),
                                    ),
                                )
                            ),
                            wp_kses_post(get_the_title())
                        )
                    );
                    wp_link_pages(
                        array(
                            'before' => '<div class="page-links">' . esc_html__('Pages:', 'brighter-blog'),
                            'after' => '</div>',
                        )
                    );
                    ?>
                </div><!-- .entry-content -->
            </div>
        </div>
        <footer class="entry-footer">
            <?php brighter_blog_entry_footer(); ?>
        </footer><!-- .entry-footer -->
    </article><!-- #post-<?php the_ID(); ?> -->
</div>


<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Brighter_Blog
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <header class="entry-header">
        <?php
        if (is_singular()) :
            the_title('<h2 class="entry-title">', '</h2>');
        else :
            the_title('<h2 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
        endif;

        if ('post' === get_post_type()) :
            ?>
            <div class="entry-meta">
                <?php
                brighter_blog_posted_on();
                brighter_blog_posted_by();
                ?>
            </div><!-- .entry-meta -->
        <?php endif; ?>
    </header><!-- .entry-header -->

    <?php brighter_blog_post_thumbnail(); ?>

    <div class="entry-content">
        <?php
        the_content(
            sprintf(
                wp_kses(
                /* translators: %s: Name of current post. Only visible to screen readers */
                    __('Continue reading<span class="screen-reader-text"> "%s"</span>', 'brighter-blog'),
                    array(
                        'span' => array(
                            'class' => array(),
                        ),
                    )
                ),
                wp_kses_post(get_the_title())
            )
        );

        wp_link_pages(
            array(
                'before' => '<div class="page-links">' . esc_html__('Pages:', 'brighter-blog'),
                'after' => '</div>',
            )
        );
        ?>
    </div><!-- .entry-content -->

    <footer class="entry-footer">
        <?php brighter_blog_entry_footer(); ?>
    </footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
