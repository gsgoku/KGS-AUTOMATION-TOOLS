<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Brighter_Blog
 */

get_header();
?>
<div class="container space-top space-extra-bottom arrow-wrap">
    <div class="row">
        <?php
        // Get the search page layout option from the theme settings
        $brighter_blog_search_page_layout_option = get_theme_mod('search_layout', 'rtl');
        ?>
        <!-- If the layout is set to 'ltl', display the sidebar on the left -->
        <?php if ($brighter_blog_search_page_layout_option == 'ltl') : 
            get_sidebar(); 
            endif; 
        ?>

        <!-- Main content area -->
        <?php if ($brighter_blog_search_page_layout_option == 'no-sidebar'): ?>
            <div class="col-12">
        <?php else: ?>
            <div class="col-xxl-8 col-lg-7">
        <?php endif; ?>
                <main id="primary" class="site-main">
                    <?php if (have_posts()) : ?>
                        <header class="page-header">
                            <h2 class="post-title blog-title single-blog-title">
                                <?php
                                /* translators: %s: search query. */
                                printf(esc_html__('Search Results for: %s', 'brighter-blog'), '<span>' . get_search_query() . '</span>');
                                ?>
                            </h2>
                        </header><!-- .page-header -->
                        <div class="post-contents with-thum-img blog-content search-shadow">
                            <div class="post-meta-item blog-meta">
                                <?php
                                /* Start the Loop */
                                while (have_posts()) :
                                    the_post();
                                    ?>
                                    <div class="col-12 single-post-item">
                                        <article id="post-<?php the_ID(); ?>" class="post-details blog-single">
                                            <div class="post-img blog-img video-wrap2">
                                                <?php the_post_thumbnail(); ?>
                                            </div>
                                            <div class="post-contents with-thum-img blog-content">
                                                <div class="post-meta-item blog-meta">
                                                    <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>" class="blog-meta-author">
                                                        <?php echo get_avatar(get_the_author_meta('ID'), 100); ?>
                                                        <?php echo esc_html(get_the_author_meta('display_name')); ?>
                                                    </a>
                                                    <a class="content-date" href="<?php echo esc_url(get_day_link(get_the_time('Y'), get_the_time('m'), get_the_time('d'))); ?>">
                                                        <i class="far fa-calendar-check"></i>
                                                        <?php echo esc_html(get_the_date()); ?>
                                                    </a>
                                                    <?php
                                                    $categories = get_the_category();
                                                    if (!empty($categories) && is_array($categories)) {
                                                        $search_cat_link = get_category_link($categories[0]->term_id);
                                                        $search_cat_name = $categories[0]->name;
                                                    } else {
                                                        $search_cat_link = '#';
                                                        $search_cat_name = '';
                                                    }
                                                    
                                                    ?>
                                                    <a class="content-category" href="<?php echo esc_url($search_cat_link); ?>">
                                                        <?php
                                                         if(!empty($categories)){ 
                                                        ?>
                                                            <i class="fas fa-pen-fancy"></i>
                                                        <?php 
                                                        } 
                                                        ?>
                                                        <?php echo esc_html($search_cat_name); ?>
                                                    </a>
                                                </div>
                                                <h2 class="post-title blog-title single-blog-title">
                                                    <a href="<?php the_permalink(); ?>">
                                                        <?php the_title(); ?>
                                                    </a>
                                                </h2>
                                                <div class="post-content blog-text">
                                                    <p>
                                                        <?php the_excerpt(); ?>
                                                    </p>
                                                </div>
                                                <div class="row post-button tagcloud-row">
                                                    <div class="col-md-8 col-sm-12 tagcloud">
                                                       
                                                        <?php
                                                        // Fetch tags for the current post
                                                        $brighter_blog_post_tags = get_the_tags(get_the_ID());

                                                        if (!empty($brighter_blog_post_tags)) {
                                                        ?>
                                                            <span class="title"><?php esc_html_e('Tags:', 'brighter-blog'); ?></span>
                                                        <?php
                                                        }
                                                        // Check if tags were returned and are an array
                                                        if ($brighter_blog_post_tags && is_array($brighter_blog_post_tags)) {
                                                            // Initialize counter
                                                            $brighter_blog_tag_count = 0;
                                                            // Loop through each tag and create a link, but limit to 5 tags
                                                            foreach ($brighter_blog_post_tags as $brighter_blog_post_tag) {
                                                                // Break the loop if the counter reaches 5
                                                                if ($brighter_blog_tag_count >= 6) {
                                                                    break;
                                                                }
                                                                ?>
                                                                <a href="<?php echo esc_url(get_tag_link($brighter_blog_post_tag->term_id)); ?>">
                                                                    <?php echo esc_html($brighter_blog_post_tag->name); ?>
                                                                </a>
                                                                <?php
                                                                // Increment the counter
                                                                $brighter_blog_tag_count++;
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                    <div class="col-md-4 col-sm-12 continue-reading">
                                                        <a href="<?php the_permalink(); ?>" class="link-btn">
                                                            <?php esc_html_e('Continue Reading', 'brighter-blog'); ?>
                                                            <i class="fas fa-angle-double-right"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </article>
                                    </div>
                                    <br>
                                    <?php
                                endwhile;
                                 
                                ?>
                                <div class="post-navigation-container">
                                    <div class="post-navigation">
                                        <?php 
                                        // Get the previous and next post links
                                        $prev_link = get_previous_posts_link('<i class="fa-solid fa-angle-left"></i> ' . esc_html__('Previous Page', 'brighter-blog'));
                                        $next_link = get_next_posts_link(esc_html__('Next Page', 'brighter-blog') . ' <i class="fa-solid fa-angle-right"></i>');
                                        ?>

                                        <?php if ($prev_link || $next_link): ?>
                                            <div class="nav-links">
                                                <?php if ($prev_link): ?>
                                                    <div class="nav-item previous-post">
                                                        <?php echo $prev_link; ?>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if ($next_link): ?>
                                                    <div class="nav-item next-post">
                                                        <?php echo $next_link; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else : ?>
                        <?php get_template_part('template-parts/content', 'none'); ?>
                    <?php endif; ?>
                </main>
            </div>

        <!-- If the layout is set to 'rtl', display the sidebar on the right -->
        <?php if ($brighter_blog_search_page_layout_option == 'rtl') : ?>
                <?php get_sidebar(); ?>
        <?php endif; ?>
    </div>
</div>

<?php
get_footer();
?>