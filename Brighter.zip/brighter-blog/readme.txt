=== Brighter-Blog ===
Contributors: mycodecare
Requires at least: 4.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.8
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/license-list.html#GPLv2
Tags: news, blog, entertainment, one-column, two-columns,three-columns,four-columns, grid-layout, editor-style, block-styles, left-sidebar, right-sidebar, custom-header, flexible-header, custom-background, custom-colors, custom-menu, featured-images, full-width-template, post-formats, sticky-post, rtl-language-support, footer-widgets, translation-ready, theme-options, threaded-comments, wide-blocks, custom-logo

== Description ==

Description: Introducing Brighter-Blog: the ultimate WordPress blog theme for news, magazines, and publishing websites. With its sleek design and customizable sidebar options, you can create a unique look that suits your brand. Brighter-Blog supports Web Stories Featured and various media formats like video and audio, keeping your readers engaged. Plus, its lightning-fast loading speeds ensure a seamless browsing experience, even on slower connections. With WPML compatibility and extensive language support, Brighter Blog is perfect for reaching a global audience. Create a professional website effortlessly with Brighter Blog.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Brighter Blog includes support for WooCommerce and for Infinite Scroll in Jetpack.

== Changelog ==

= 1.0.0 =
* Initial Release
= 1.0.1 =
* Bug Fix
= 1.0.2 =
* Bug Fix
= 1.0.3 =
* fix keyboard navigation
= 1.0.4 =
* Add demo content
= 1.0.5 =
* fix demo content
= 1.0.6 =
* update demo content
= 1.0.7 =
* update kirki
= 1.0.8 =
* Compatibility with WordPress 6.8

== Copyright ==

Brighter Blog WordPress theme for news, Copyright 2018-2022 by mycodecare Brighter Blog is distributed under the terms of the GNU GPL
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see http://www.gnu.org/licenses/gpl-2.0.html

Brighter Blog is based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc.


Brighter Blog Theme bundles the following third-party resources:

- Bootstrap v5.0.0-beta1
    -- Copyright 2011-2022 The Bootstrap Authors
    -- Copyright 2011-2022 Twitter, Inc.
    -- License: MIT (https://github.com/twbs/bootstrap/blob/main/LICENSE)
    -- Source: http://getbootstrap.com/

- Font-Awesome 
	-- Font Awesome Free 6.0.0
	-- https://github.com/FortAwesome/Font-Awesome.git
	-- https://github.com/FortAwesome/Font-Awesome/blob/master/LICENSE.txt

- Stellar Nav
	-- Copyright (c) 2016 Vinny Moreira
	-- Licensed: https://github.com/vinnymoreira/stellarnav/blob/master/LICENSE

- Kirki Customizer Framework
    -- Copyright (c) 2019, Ari Stathopoulos (@aristath)
    -- License URI: https://opensource.org/licenses/MIT (License: MIT)

    
- jQuery Superfish Menu
    -- Copyright (c) 2013 Joel Birch
    -- License: Dual licensed under the MIT and GPL licenses (http://opensource.org/licenses/MIT)
    -- Source: http://users.tpg.com.au/j_birch/plugins/superfish/

- jQuery slicknav For Mobile
    -- Copyright (c) 2016 Josh Cope
    -- License: https://github.com/ComputerWolf/SlickNav/blob/master/MIT-LICENSE.txt
    -- Source: https://github.com/ComputerWolf/SlickNav

- jQuery Magnific-Popup
    -- Copyright (c) 2016 Dmitry Semenov, v1.1.0 - 2016-02-20
    -- License: https://github.com/dimsemenov/Magnific-Popup/blob/master/LICENSE
    -- Source: https://github.com/dimsemenov/Magnific-Popup

- jQuery Isotop
    -- Copyright 2015 Metafizzy
    -- License: MIT (http://opensource.org/licenses/MIT)
    -- Source: https://isotope.metafizzy.co
    
- Customizer-Pro =
    -- Name of Author: Justin Tadlock
    -- Copyright 2016, Justin Tadlock justintadlock.com
    -- https://github.com/justintadlock/trt-customizer-pro
    -- License: GNU General Public License v2.0
    -- http://www.gnu.org/licenses/gpl-2.0.html

- AcmeTicker =
    -- Copyright (c) 2020 Acme Information Technology Pvt. Ltd.
    -- https://github.com/codersantosh/acmeticker/blob/master/LICENSE
    -- Source: https://github.com/codersantosh/acmeticker

- Google Font 
    -- Font by Smartsheet Inc, Rodrigo Fuenzalida
    -- Licensed under Open Font License
    -- https://fonts.google.com/specimen/Outfit
    -- Font by Alfredo Marco Pradil, Hanken Design Co.
    -- Licensed under Open Font License
    -- https://fonts.google.com/specimen/Hanken+Grotesk

- All Images, Copyright stocksnap.io
    -- License: Creative Commons CC0 license.
    -- License URI: https://stocksnap.io/license

- Screenshot images By https://pxhere.com/
    -- License: CC0 1.0 Universal (CC0 1.0)
	-- Source: https://pxhere.com/en/photo/1410926
	-- Source: https://pxhere.com/en/photo/1238803
