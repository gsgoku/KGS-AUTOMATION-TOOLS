<?php
get_header();
//Set tag color array
$brighter_blog_tag_color = array('white');

?>
<main id="primary" class="site-main">
    <div class="page-wrapper brighter-blog-front-page-wrapper">
        <!--==============================
               Hero Area
        ==============================-->

        <div class="hero-wrapper hero-1 space-top" id="hero">
            <div class="container">
                <div class="row gy-20 gx-20">
                    <?php
                    $brighter_blog_hero_select = get_theme_mod('select_hero', 'one');
                    get_template_part('inc/hero/hero-' . $brighter_blog_hero_select);
                    ?>
                </div>
            </div>
        </div>
        <!--======== / Hero Section ========-->


        <!-- =========================================================
        Top Category area Starts
       ============================================================ -->
        <?php if (get_theme_mod('top_category_enable', true)) : ?>

            <div class="top-category-section space">
                <div class="container">
                    <?php
                    $top_category_section_title = get_theme_mod('top_category_section_title', 'Top Category');
                    ?>
                    <h2 class="top-category-title section-title wow animate__fadeIn"><?php echo esc_html($top_category_section_title); ?></h2>
                    <div class="row gy-20 gx-20">
                        <div class="top-category-list p-4">
                            <?php

                            $top_selected_categories = get_theme_mod('top_selected_categories', []); // Get selected categories
                            $top_category_display_number = get_theme_mod('top_category_display_number', 10);
                            $cat_default_icon = get_template_directory_uri() . '/assets/images/category-icon/default-category.svg';

                            // Fetch categories based on selection or latest categories
                            if (empty($top_selected_categories)) {
                                $top_categories = get_categories([
                                    'orderby' => 'date',
                                    'order'   => 'desc',
                                    'number'  => $top_category_display_number,
                                ]);
                            } else {
                                $top_categories = get_categories([
                                    'include' => $top_selected_categories,
                                    'orderby' => 'include',
                                    'number'  => $top_category_display_number,
                                ]);
                            }

                            // If no categories are found, fetch random categories
                            if (empty($top_categories)) {
                                $top_categories = get_categories([
                                    'orderby' => 'rand',
                                    'number'  => $top_category_display_number,
                                ]);
                            }
                            // Display the categories
                            foreach ($top_categories as $top_category) {
                                $icon_url = get_term_meta($top_category->term_id, 'icon_for_category', true);
                                ?>
                                <a href="<?php echo esc_url(get_category_link($top_category->term_id)) ?>" class="category-item">
                                    <?php
                                    if ($icon_url):
                                        ?>
                                        <img src="<?php echo esc_url($icon_url)?>" alt="<?php echo esc_attr($top_category->name); ?>" class="category-icon" style="width: 20px; height: 20px; margin-right: 5px;">
                                    <?php
                                    else:
                                        ?>
                                        <img src="<?php echo esc_url($cat_default_icon)?>" alt="<?php echo esc_attr($top_category->name); ?>" class="category-icon" style="width: 20px; height: 20px; margin-right: 5px;">
                                    <?php
                                    endif;
                                    ?>
                                    <span><?php echo esc_html($top_category->name);?></span>
                                </a>
                                <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

        <?php
        endif;
        ?>
        <!--================= Hero Ads Code Starts ============== -->
        <?php if (get_theme_mod('hero_ads_enable', true)) : ?>
            <section class="hero-ads space">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="ad-banner-wrap">
                                <?php
                                $brighter_blog_hero_ads_image = get_theme_mod('hero_ads_image', get_template_directory_uri() . '/assets/images/ads/ads-2.png');
                                $brighter_blog_hero_ads_url = get_theme_mod('hero_ads_image_url', '#');
                                if($brighter_blog_hero_ads_image){
                                    ?>
                                    <a class="hero-ads" href="<?php echo esc_url_raw($brighter_blog_hero_ads_url); ?>" target="_blank">
                                        <img class="ads-img" src="<?php echo esc_url($brighter_blog_hero_ads_image); ?>" alt="Hero Ads">
                                    </a>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        <?php
        endif;
        ?>




        <!--================ Latest Post Section Starts ====================== -->

        <?php if (get_theme_mod('latest_post_section_enable', true)) : ?>
            <section class="latest-post">
                <div class="container">
                    <?php
                    $latest_post_section_title = get_theme_mod('latest_post_section_title', 'Latest Post');
                    ?>
                    <h2 class="latest-post-title section-title wow animate__fadeIn"><?php echo esc_html($latest_post_section_title); ?></h2>
                    <div class="row gy-20 gx-20">
                        <?php
                        $latest_side_bar_enable = get_theme_mod('latest_side_bar_enable', 'on');
                        if ($latest_side_bar_enable == 'on') {
                            $latest_post_class = 'col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12';
                        }else {
                            $latest_post_class = 'col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12';
                        }
                        ?>
                        <div class="<?php echo esc_attr($latest_post_class) ?>">
                            <div class="row gy-20 gx-20">
                                <?php
                                // Fetch selected category from the Customizer
                                $latest_post_category = get_theme_mod('latest_post_category', '');
                                $latest_post_order = get_theme_mod('latest_post_order', 'desc');
                                $latest_post_orderby = get_theme_mod('latest_post_orderby', 'date');
                                $latest_post_display_number = get_theme_mod('latest_post_display_number', '4');

                                // Build query arguments
                                $latest_post_query_args = [
                                    'post_type'      => 'post',
                                    'orderby' => $latest_post_orderby, // Order by post count
                                    'order'   => $latest_post_order,  // Descending order
                                    'posts_per_page' => $latest_post_display_number, // Adjust the number of posts to show
                                    'ignore_sticky_posts' => 1,
                                ];

                                if (!empty($latest_post_category)) {
                                    $latest_post_query_args['category_name'] = $latest_post_category;
                                }

                                $latest_posts_query = new WP_Query($latest_post_query_args);

                                if ($latest_posts_query->have_posts()) {
                                    while ($latest_posts_query->have_posts()) {
                                        $latest_posts_query->the_post();
                                        $latest_post_random_color_array = array_rand($brighter_blog_tag_color, 1);
                                        // Get the post thumbnail or fallback image
                                        $latest_post_image = (has_post_thumbnail()) ? get_the_post_thumbnail_url(get_the_ID(), 'large') : get_template_directory_uri() . '/assets/images/no-image.jpg';
                                        $brighter_blog_post_thumbnail_id = get_post_thumbnail_id(get_the_ID());
                                        if (get_the_post_thumbnail_url()) {
                                            $brighter_blog_latest_post_image_alt_text = get_post_meta($brighter_blog_post_thumbnail_id, '_wp_attachment_image_alt', true);
                                        } else {
                                            $brighter_blog_latest_post_image_alt_text = 'No Image';
                                        }
                                        if (strlen(get_the_title()) > 5) {
                                            // Trim to the first 5 characters and add ellipsis
                                            $brighter_blog_latest_post_title = substr(get_the_title(), 0, 35) . '...';
                                        } else {
                                            // If the title is less than or equal to 5 characters, display it as is
                                            $brighter_blog_latest_post_title = get_the_title();
                                        }
                                        ?>
                                        <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 mb-3">
                                            <div class="news-card">
                                                <div class="news-card-image">
                                                    <img src="<?php echo esc_url($latest_post_image); ?>" alt="<?php echo esc_attr($brighter_blog_latest_post_image_alt_text); ?>" />
                                                    <div class="news-card-tags ">
                                                        <?php
                                                        $categories = get_the_category();
                                                        if (!empty($categories)) {
                                                            $limited_categories = array_slice($categories, 0, 5); // Limit to 5 categories
                                                            foreach ($limited_categories as $category) {
                                                                ?>
                                                                <span class="post-category style-<?php echo esc_attr($brighter_blog_tag_color[$latest_post_random_color_array]); ?>">
                                                    <?php echo esc_html($category->name); ?>
                                                </span>
                                                                <?php
                                                            }
                                                        }
                                                        ?>

                                                    </div>
                                                </div>
                                                <div class="news-card-content">
                                                    <div class="news-card-meta">
                                                        <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>" class="author">
                                                            <?php the_author(); ?>
                                                        </a>
                                                        <span class="date"><?php echo esc_html('on'); ?> <?php echo get_the_date(); ?></span>
                                                    </div>
                                                    <h2 class="news-card-title"><a class="post-title" href="<?php echo esc_url(get_the_permalink()); ?>"><?php echo esc_html($brighter_blog_latest_post_title); ?></a></h2>
                                                    <p class="news-card-description">
                                                        <?php echo wp_trim_words(get_the_excerpt(), 10, '...'); ?>
                                                    </p>
                                                    <?php $latest_post_btn_text = get_theme_mod('latest_post_btn_text', 'Discover More'); ?>
                                                    <a href="<?php the_permalink(); ?>" class="news-card-button"><?php echo esc_html($latest_post_btn_text); ?></a>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    wp_reset_postdata();
                                }
                                ?>
                            </div>
                        </div>
                        <?php
                        if ($latest_side_bar_enable == "on") {
                            ?>
                            <!-- Related Widget start here  -->
                            <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12">
                                <div class="sidebar-latest">
                                    <?php if (is_active_sidebar('latest-sidebar')) : ?>
                                        <?php if (is_active_sidebar('latest-sidebar')) : ?>
                                            <div class="sidebar-widget-area">
                                                <?php dynamic_sidebar('latest-sidebar'); ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php
                        }
                        ?>

                    </div>
                </div>
            </section>
        <?php
        endif;
        ?>

        <!--======================= Editor Pick Section Starts ======================= -->
        <?php if (get_theme_mod('editor_pick_section_enable', true)) : ?>
            <section class="editor-pick">
                <div class="container">
                    <?php
                    $editor_pick_section_title = get_theme_mod('editor_pick_section_title', 'Editor Pick');
                    ?>
                    <h2 class="editor-pick-title section-title wow animate__fadeIn"><?php echo esc_html($editor_pick_section_title); ?></h2>
                    <div class="row gy-20 gx-20">
                        <div class="col-12">

                            <div class="row gy-20 gx-20">

                                <?php
                                // Get selected category from Customizer
                                $editor_pick_post_category = get_theme_mod('editor_pick_post_category', '');
                                $editor_pick_order = get_theme_mod('editor_pick_order', 'desc');
                                $editor_pick_orderby = get_theme_mod('editor_pick_orderby', 'date');
                                $editor_pick_display_number = get_theme_mod('editor_pick_display_number', '4');

                                // Query posts
                                $editor_pick_query_args = [
                                    'post_type'      => 'post',
                                    'order'         => $editor_pick_order,
                                    'orderby'         => $editor_pick_orderby,
                                    'posts_per_page' => $editor_pick_display_number, // Fetch a single post
                                    'ignore_sticky_posts' => 1,
                                ];

                                if (!empty($editor_pick_post_category)) {
                                    $editor_pick_query_args['category_name'] = $editor_pick_post_category;
                                }

                                $editor_pick_post_query = new WP_Query($editor_pick_query_args);

                                if ($editor_pick_post_query->have_posts()) {
                                    while ($editor_pick_post_query->have_posts()) {
                                        $editor_pick_post_query->the_post();
                                        $editor_pick_random_color_array = array_rand($brighter_blog_tag_color, 1);
                                        // Get post thumbnail or fallback image
                                        $editor_pick_post_image = (has_post_thumbnail()) ? get_the_post_thumbnail_url(get_the_ID(), 'large') : get_template_directory_uri() . '/assets/images/no-image.jpg';
                                        $brighter_blog_post_thumbnail_id = get_post_thumbnail_id(get_the_ID());
                                        if (get_the_post_thumbnail_url()) {
                                            $brighter_blog_editor_pick_post_image_alt_text = get_post_meta($brighter_blog_post_thumbnail_id, '_wp_attachment_image_alt', true);
                                        } else {
                                            $brighter_blog_editor_pick_post_image_alt_text = 'No Image';
                                        }
                                        if (strlen(get_the_title()) > 5) {
                                            // Trim to the first 5 characters and add ellipsis
                                            $brighter_blog_editor_pick_post_title = substr(get_the_title(), 0, 35) . '...';
                                        } else {
                                            // If the title is less than or equal to 5 characters, display it as is
                                            $brighter_blog_editor_pick_post_title = get_the_title();
                                        }
                                        ?>
                                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-12 col-12">
                                            <div class="post-card">
                                                <div class="post-card-image">
                                                    <img src="<?php echo esc_url($editor_pick_post_image); ?>" alt="<?php echo esc_attr($brighter_blog_editor_pick_post_image_alt_text); ?>" />
                                                    <div class="post-card-tag">
                                                        <?php
                                                        $categories = get_the_category();
                                                        if (!empty($categories)) {
                                                            ?>
                                                            <span class="tag post-category style-<?php echo esc_attr($brighter_blog_tag_color[$editor_pick_random_color_array]); ?>"> <?php echo esc_html($categories[0]->name); ?></span>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                <div class="post-card-content">
                                                    <h3 class="post-card-title">
                                                        <a class="post-title" href="<?php echo esc_url(get_the_permalink()); ?>">
                                                            <?php echo esc_html($brighter_blog_editor_pick_post_title); ?>
                                                        </a>
                                                    </h3>
                                                    <p class="post-card-description">
                                                        <?php echo wp_trim_words(get_the_excerpt(), 10, '...'); ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    wp_reset_postdata();
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        <?php
        endif;
        ?>




        <?php if (get_theme_mod('middle_ads_enable', true)) : ?>

            <section class="middle-ads space">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="ad-banner-wrap">
                                <?php
                                $brighter_blog_middle_ads_image = get_theme_mod('middle_ads_image', get_template_directory_uri() . '/assets/images/ads/ads-3.png');
                                $brighter_blog_middle_ads_url = get_theme_mod('middle_ads_image_url', '#');
                                if($brighter_blog_middle_ads_image){
                                    ?>
                                    <a class="middle-ads" href="<?php echo esc_url_raw($brighter_blog_middle_ads_url); ?>" target="_blank">
                                        <img class="ads-img" src="<?php echo esc_url($brighter_blog_middle_ads_image); ?>" alt="Middle Ads">
                                    </a>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
        <?php
        endif;
        ?>

        <!--=================== Trending Post Section Starts ======================= -->
        <?php if (get_theme_mod('trending_post_enable', true)) : ?>

            <section class="trending-post">
                <div class="container">
                    <?php
                    $trending_post_section_title = get_theme_mod('trending_post_section_title', 'Trending');
                    ?>
                    <h2 class="trending-post-title section-title wow animate__fadeIn"><?php echo esc_html($trending_post_section_title) ?></h2>
                    <div class="row gy-20 gx-20">
                        <?php
                        // Get selected category from Customizer
                        $trending_post_category = get_theme_mod('trending_post_category', '');
                        $trending_post_order = get_theme_mod('trending_post_order', 'desc');
                        $trending_post_orderby = get_theme_mod('trending_post_orderby', 'date');
                        $trending_post_display_number = get_theme_mod('trending_post_display_number', '6');

                        // Query posts
                        $trending_post_query_args = [
                            'post_type'      => 'post',
                            'order'         => $trending_post_order,
                            'orderby'         => $trending_post_orderby,
                            'posts_per_page' => $trending_post_display_number, // Fetch a single post
                            'ignore_sticky_posts' => 1,
                        ];

                        if (!empty($trending_post_category)) {
                            $trending_post_query_args['category_name'] = $trending_post_category;
                        }

                        $trending_post_query = new WP_Query($trending_post_query_args);

                        if ($trending_post_query->have_posts()) {
                            while ($trending_post_query->have_posts()) {
                                $trending_post_query->the_post();
                                $trending_post_random_color_array = array_rand($brighter_blog_tag_color, 1);
                                // Get post thumbnail or fallback image
                                $trending_post_image = (has_post_thumbnail()) ? get_the_post_thumbnail_url(get_the_ID(), 'large') : get_template_directory_uri() . '/assets/images/no-image.jpg';
                                if (strlen(get_the_title()) > 5) {
                                    // Trim to the first 5 characters and add ellipsis
                                    $brighter_blog_trending_post_title = substr(get_the_title(), 0, 35) . '...';
                                } else {
                                    // If the title is less than or equal to 5 characters, display it as is
                                    $brighter_blog_trending_post_title = get_the_title();
                                }
                                ?>
                                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 mb-3">
                                    <div class="post-card">
                                        <div class="post-card-image" style="background-image: url('<?php echo esc_url($trending_post_image); ?>');">
                                            <div class="post-card-overlay">
                                <span class="tag post-category style-<?php echo esc_attr($brighter_blog_tag_color[$trending_post_random_color_array]); ?>">
                                    <?php
                                    $categories = get_the_category();
                                    if (!empty($categories)) {
                                        echo esc_html($categories[0]->name);
                                    }
                                    ?>
                                </span>
                                                <h2 class="post-card-title"><a class="post-title" href="<?php echo esc_url(get_the_permalink()); ?>"><?php echo esc_html($brighter_blog_trending_post_title); ?></a></h2>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            wp_reset_postdata();
                        }
                        ?>

                    </div>
                </div>
            </section>

        <?php
        endif;
        ?>

        <!--==============================
             Video Area
         ==============================-->

        <?php
        if ( get_theme_mod( 'enable_video_section', false ) ) :

            $video_section_title = get_theme_mod('video_section_title', 'Video Post');
            ?>
            <div class="space overflow-hidden bg-black">
                <div class="container container2">
                    <div class="row align-items-center justify-content-sm-between justify-content-center">
                        <div class="col-auto">
                            <h2 class="sec-title h3 text-center text-white video-edit"><?php echo esc_html($video_section_title); ?></h2>
                        </div>
                        <div class="col d-sm-block d-none">
                            <hr class="title-line style2">
                        </div>
                    </div>
                    <?php

                    $brighter_blog_video_post_category = get_theme_mod('select_video_category', array(1));
                    $brighter_blog_video_order = get_theme_mod('news_video_post_order', 'desc');
                    $brighter_blog_video_orderby = get_theme_mod('news_video_post_order_by', 'title');
                    $brighter_blog_video_post_number = get_theme_mod('news_video_total_number', '5');
                    $brighter_blog_video_post_args = array(
                        'meta_query' => array(array('key' => 'video_url',
                            'compare' => 'EXISTS',),),
                        'category__in' => $brighter_blog_video_post_category,
                        'order' => $brighter_blog_video_order,
                        'orderby' => $brighter_blog_video_orderby,
                        'posts_per_page' => $brighter_blog_video_post_number,);
                    $brighter_blog_video_post_query = new WP_Query($brighter_blog_video_post_args);
                    ?>
                    <div class="row gx-40 gy-40">
                        <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12">
                            <div class="blog-tab-slide global-carousel" data-fade="true" data-slide-show="1"
                                 data-md-slide-show="1" data-adaptive-height="true">
                                <?php
                                if ($brighter_blog_video_post_query->have_posts()) :
                                    while ($brighter_blog_video_post_query->have_posts()) : $brighter_blog_video_post_query->the_post();
                                        $brighter_blog_video_post_get_video_url = get_post_meta(get_the_ID(), 'video_url', true);
                                        $brighter_blog_video_post_categories = get_the_category();
                                        $brighter_blog_video_post_img = (get_the_post_thumbnail_url()) ? get_the_post_thumbnail_url() : get_template_directory_uri() . '/assets/images/no-image.jpg';
                                        // Get post date
                                        $brighter_blog_video_post_date = get_the_date('Y-m-d');
                                        // Get the post thumbnail ID
                                        $brighter_blog_video_post_thumbnail_id = get_post_thumbnail_id(get_the_ID());
                                        if(get_the_post_thumbnail_url()){
                                            $video_post_image_alt_text = get_post_meta($brighter_blog_video_post_thumbnail_id, '_wp_attachment_image_alt', true);
                                        }
                                        else{
                                            $video_post_image_alt_text = 'No Image';
                                        }
                                        // Extract year, month, and day
                                        $brighter_blog_what_new_year = get_the_date('Y');
                                        $brighter_blog_what_new_month = get_the_date('m');
                                        $brighter_blog_what_new_day = get_the_date('d');

                                        // Get date URL
                                        $brighter_blog_video_date_url = get_day_link($brighter_blog_what_new_year, $brighter_blog_what_new_month, $brighter_blog_what_new_day);
                                        $brighter_blog_video_main_title = wp_trim_words( get_the_title(), 8, '...' )
                                        ?>
                                        <div class="">
                                            <div class="single-blog-post style4">
                                                <div class="post-img video-wrap">
                                                    <img class="vid-h-w" src="<?php echo esc_url($brighter_blog_video_post_img) ?>"
                                                         alt="<?php echo esc_attr($video_post_image_alt_text); ?>">
                                                    <a href="<?php echo esc_url($brighter_blog_video_post_get_video_url); ?>"
                                                       class="play-btn popup-video">
                                                        <i class="fas fa-play"></i>
                                                    </a>
                                                </div>
                                                <div class="post-wrap-details">
                                                    <h4 class="post-title fw-medium h2 mt-30">
                                                        <a class="text-white style-underline-none" href="<?php the_permalink(); ?>">
                                                            <?php echo esc_html($brighter_blog_video_main_title); ?>
                                                        </a>
                                                    </h4>
                                                    <a href="<?php echo esc_url($brighter_blog_video_date_url); ?>" class="post-date mt-35 style-underline-none">
                                                        <i class="far fa-clock"></i>
                                                        <?php echo esc_html(get_the_date()); ?>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                    endwhile;
                                    wp_reset_postdata(); // Restore original Post Data
                                endif;
                                ?>
                            </div>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12">
                            <div class="blog-tab" data-asnavfor=".blog-tab-slide">
                                <?php
                                if ($brighter_blog_video_post_query->have_posts()) :
                                    while ($brighter_blog_video_post_query->have_posts()) : $brighter_blog_video_post_query->the_post();
                                        $brighter_blog_get_video_url = get_post_meta(get_the_ID(), 'video_url', true);
                                        $brighter_blog_video_post_category = get_the_category();
                                        $cat_url = get_category_link($brighter_blog_video_post_category[0]->term_id);
                                        $brighter_blog_tag_color = array('style-dark-green', 'style-red', 'style-blue'); // Example colors, adjust as needed
                                        // Get the categories of the specific post

                                        if (!empty($brighter_blog_video_post_category)) {
                                            $custom_field_cat_color = get_term_meta($brighter_blog_video_post_category[0]->term_id, 'term_color', true);
                                            $random_color = $brighter_blog_tag_color[array_rand($brighter_blog_tag_color)];
                                        } else {
                                            $custom_field_cat_color = '';
                                        }

                                        $brighter_blog_video_post_img = (get_the_post_thumbnail_url()) ? get_the_post_thumbnail_url() : get_template_directory_uri() . '/assets/images/no-image.jpg';
                                        $brighter_blog_get_video_icon = get_template_directory_uri() . '/assets/images/wave.svg';
                                        // Get the post thumbnail ID
                                        $video_post_image_thumbnail_id = get_post_thumbnail_id(get_the_ID());
                                        if(get_the_post_thumbnail_url()){
                                            $video_post_image_alt_text = get_post_meta($video_post_image_thumbnail_id, '_wp_attachment_image_alt', true);
                                        }
                                        else{
                                            $video_post_image_alt_text = 'No Image';
                                        }
                                        // Get post date
                                        $post_date = get_the_date('Y-m-d');

                                        // Extract year, month, and day
                                        $brighter_blog_what_new_year = get_the_date('Y');
                                        $brighter_blog_what_new_month = get_the_date('m');
                                        $brighter_blog_what_new_day = get_the_date('d');

                                        // Get date URL
                                        $date_url = get_day_link($brighter_blog_what_new_year, $brighter_blog_what_new_month, $brighter_blog_what_new_day);
                                        $brighter_blog_video_right_title = wp_trim_words( get_the_title(), 5, '...' )
                                        ?>
                                        <div class="tab-btn active">
                                            <div class="single-blog-post style-grid">
                                                <div class="post-img img-radius-5 video-wrap">
                                                    <img class="post-img-wh" src="<?php echo esc_url($brighter_blog_video_post_img); ?>" alt="<?php echo esc_attr($video_post_image_alt_text)  ?>">
                                                    <div class="icon wave-icon">
                                                        <img src="<?php echo esc_url($brighter_blog_get_video_icon); ?>" alt="<?php echo esc_attr($video_post_image_alt_text) ?>">
                                                    </div>
                                                    <a href="<?php echo esc_url($brighter_blog_get_video_url); ?>"
                                                       class="play-btn style2 popup-video">
                                                        <i class="fas fa-play"></i>
                                                    </a>
                                                </div>

                                                <div class="post-wrap-details">
                                                    <a href="<?php echo esc_url($cat_url); ?>" class="post-category style-underline-none <?php echo esc_attr($random_color); ?>" style="background : <?php echo esc_attr($custom_field_cat_color); ?>">
                                                        <?php echo esc_html($brighter_blog_video_post_category[0]->name); ?>
                                                    </a>
                                                    <h6 class="post-title mt-15 fw-medium">
                                                        <a class="text-white style-underline-none" href="<?php the_permalink(); ?>">
                                                            <?php echo esc_html($brighter_blog_video_right_title); ?>
                                                        </a>
                                                    </h6>
                                                </div>
                                            </div>
                                        </div>
                                    <?php
                                    endwhile;
                                    wp_reset_postdata(); // Restore original Post Data
                                endif;
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        endif;
        ?>
        <!--=================== In Focus Section Starts ========================== -->
        <?php if (get_theme_mod('enable_in_focus_section', true)) : ?>

            <section class="in-focus space">
                <div class="container">
                    <?php
                    $in_focus_section_title = get_theme_mod('in_focus_section_title', 'In Focus');
                    ?>
                    <h2 class="in-focus-title section-title wow animate__fadeIn"><?php echo esc_html($in_focus_section_title) ?></h2>
                    <div class="row gy-20 gx-20">
                        <?php
                        $in_focus_side_bar_enable = get_theme_mod('infocus_side_bar_enable_disable', 'on');
                        if ($in_focus_side_bar_enable == 'on') {
                            $in_focus_post_class = 'col-xl-8 col-md-8';
                        }else {
                            $in_focus_post_class = 'col-xl-12 col-md-12';
                        }
                        ?>
                        <div class="<?php echo esc_attr($in_focus_post_class); ?>">



                            <?php
                            // Get selected category from Customizer
                            $in_focus_post_category = get_theme_mod('in_focus_post_category', '');
                            $in_focus_post_order = get_theme_mod('in_focus_post_order', 'desc');
                            $in_focus_post_orderby = get_theme_mod('in_focus_post_orderby', 'date');
                            $in_focus_post_display_number = get_theme_mod('in_focus_post_display_number', '4');

                            // Query posts
                            $in_focus_query_args = [
                                'post_type'      => 'post',
                                'order'         => $in_focus_post_order,
                                'orderby'         => $in_focus_post_orderby,
                                'posts_per_page' => $in_focus_post_display_number, // Fetch a single post
                                'ignore_sticky_posts' => 1,
                            ];

                            if (!empty($in_focus_post_category)) {
                                $in_focus_query_args['category_name'] = $in_focus_post_category;
                            }

                            $in_focus_post_query = new WP_Query($in_focus_query_args);

                            if ($in_focus_post_query->have_posts()) {
                                while ($in_focus_post_query->have_posts()) {
                                    $in_focus_post_query->the_post();
                                    $in_focus_post_random_color_array = array_rand($brighter_blog_tag_color, 1);
                                    // Get post thumbnail or fallback image
                                    $in_focus_post_image = (has_post_thumbnail()) ? get_the_post_thumbnail_url(get_the_ID(), 'large') : get_template_directory_uri() . '/assets/images/no-image.jpg';
                                    $brighter_blog_post_thumbnail_id = get_post_thumbnail_id(get_the_ID());
                                    if (get_the_post_thumbnail_url()) {
                                        $brighter_blog_in_focus_post_image_alt_text = get_post_meta($brighter_blog_post_thumbnail_id, '_wp_attachment_image_alt', true);
                                    } else {
                                        $brighter_blog_in_focus_post_image_alt_text = 'No Image';
                                    }
                                    if (strlen(get_the_title()) > 5) {
                                        // Trim to the first 5 characters and add ellipsis
                                        $brighter_blog_in_focus_post_title = substr(get_the_title(), 0, 35) . '...';
                                    } else {
                                        // If the title is less than or equal to 5 characters, display it as is
                                        $brighter_blog_in_focus_post_title = get_the_title();
                                    }
                                    ?>
                                    <div class="row news-card mb-4">
                                        <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                                            <div class="news-card-image">
                                                <img src="<?php echo esc_url($in_focus_post_image); ?>" alt="<?php echo esc_attr($brighter_blog_in_focus_post_image_alt_text) ?>" />
                                                <div class="news-card-tags">
                                                    <?php
                                                    $categories = get_the_category();
                                                    if (!empty($categories)) {
                                                        $in_focus_limited_categories = array_slice($categories, 0, 2); // Limit to 2 categories
                                                        foreach ($in_focus_limited_categories as $category) {
                                                            ?>
                                                            <span class="tag post-category style-<?php echo esc_attr($brighter_blog_tag_color[$in_focus_post_random_color_array]); ?>"><?php echo esc_html($category->name); ?></span>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                                            <div class="news-card-content">
                                                <div class="news-card-meta">
                                                    <a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>" class="author">
                                                        <?php the_author(); ?>
                                                    </a>
                                                    <span class="date">on <?php echo get_the_date(); ?></span>
                                                </div>
                                                <h2 class="news-card-title"><a href="<?php echo esc_url(the_permalink()) ?>" class="post-title"><?php echo esc_html($brighter_blog_in_focus_post_title); ?></a></h2>
                                                <p class="news-card-description">
                                                    <?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?>
                                                </p>
                                                <?php
                                                $button_text = get_theme_mod('in_focus_btn_text', 'Discover More');
                                                ?>
                                                <a href='<?php echo esc_url(get_permalink()); ?>' class='news-card-button'><?php echo esc_html($button_text); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                }
                                wp_reset_postdata();
                            }
                            ?>
                        </div>
                        <?php
                        if ($in_focus_side_bar_enable == "on") {
                            ?>
                            <!-- Related Widget start here  -->
                            <div class="col-xl-4 col-md-12">
                                <div class="sidebar-in-focus">
                                    <?php if (is_active_sidebar('in-focus-sidebar')) : ?>
                                        <?php if (is_active_sidebar('in-focus-sidebar')) : ?>
                                            <div class="sidebar-widget-area">
                                                <?php dynamic_sidebar('in-focus-sidebar'); ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </section>

        <?php
        endif;
        ?>

</main>
<?php
get_footer();


 