<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Brighter_Blog
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>

<aside id="secondary" class="col-xxl-4 col-lg-5 sidebar-widget-area">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside><!-- #secondary -->


<?php

if ( ! is_active_sidebar( 'what-new-sidebar' ) ) {
	return;
}
?>

<aside id="second-sidebar" class="col-xxl-4 col-lg-5 sidebar-widget-area">
	<?php dynamic_sidebar( 'what-new-sidebar' ); ?>
</aside><!-- #second-sidebar -->

<?php

if ( ! is_active_sidebar( 'more-news-sidebar' ) ) {
	return;
}
?>

<aside id="third-sidebar" class="col-xxl-4 col-lg-5 sidebar-widget-area">
	<?php dynamic_sidebar( 'more-news-sidebar' ); ?>
</aside><!-- #third-sidebar -->

<?php

if ( ! is_active_sidebar( 'more-news-two-sidebar' ) ) {
	return;
}
?>

<aside id="fourth-sidebar" class="col-xxl-4 col-lg-5 sidebar-widget-area">
	<?php dynamic_sidebar( 'more-news-two-sidebar' ); ?>
</aside><!-- #fourth-sidebar -->