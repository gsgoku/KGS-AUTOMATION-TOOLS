<?php

Kirki::add_config( 'theme_config', array(
	'capability'  => 'edit_theme_options',
	'option_type' => 'theme_mod',
) );

    //Check Pro version 
    if (!class_exists('Brighter_Blog_Pro')) {
        require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/reset-customizer.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    

    // Assuming BRIGHTER_BLOG_INC_DIR is defined and points to the includes directory.
    require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/header/header-settings.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/header/header-top.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/header/header-middle.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/header/header-bottom.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound


    /**
     *  * Font page Options for theme
     */
    require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/font-page/font-page-settings.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/font-page/hero.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/font-page/top-category.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    }

    require BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/font-page/hero-ads.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    
    if (!class_exists('Brighter_Blog_Pro')) {
    require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/font-page/latest-post.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/font-page/editor-pick.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    }

    require BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/font-page/middle-ads.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

    if (!class_exists('Brighter_Blog_Pro')) {
    require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/font-page/trending-post.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/font-page/tending-video.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/font-page/in-focus.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    }

    /**
     * Theme setting Options
     */
     require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/options-kirki/options-kirki.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    
     require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/options-kirki/theme-typography.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

     if (!class_exists('Brighter_Blog_Pro')) {
     require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/options-kirki/theme-general.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
     }
     require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/options-kirki/blog-options.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
   
     /**
     * General Options for footer
     */
     require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/footer/footer-settings.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
     //Check Pro version 
    if (!class_exists('Brighter_Blog_Pro')) {

     require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/free/footer/footer-copyright.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    }



 
/**
 * Page layout settings pro and free common code start
 */
require BRIGHTER_BLOG_INC_DIR . 'kirki-customize/page-layout/blog-page-layout-settings.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

/**
 * Page layout Options free and pro 
 */

require BRIGHTER_BLOG_INC_DIR . 'kirki-customize/page-layout/blog-options.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require BRIGHTER_BLOG_INC_DIR . 'kirki-customize/page-layout/blog-page-options.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require BRIGHTER_BLOG_INC_DIR . 'kirki-customize/page-layout/archive-options.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require BRIGHTER_BLOG_INC_DIR . 'kirki-customize/page-layout/error-options.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require BRIGHTER_BLOG_INC_DIR . 'kirki-customize/page-layout/search-options.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require BRIGHTER_BLOG_INC_DIR . 'kirki-customize/page-layout/single-page-options.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
require_once BRIGHTER_BLOG_INC_DIR . 'kirki-customize/page-layout/shop-page.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
/**
 * Page layout settings pro and free common code Ends
 */
    