<?php
function brighter_blog_top_category_customizer_quick_edit() {
    // Retrieve the updated title from the Customizer setting.
    $news_title_content = get_theme_mod('top_category_section_title', __('Top Category', 'brighter-blog'));

    // Return the updated title.
    return esc_html($news_title_content);
}

function brighter_latest_post_customizer_quick_edit() {
    // Retrieve the updated title from the Customizer setting.
    $news_title_content = get_theme_mod('latest_post_section_title', __('Latest Post', 'brighter-blog'));

    // Return the updated title.
    return esc_html($news_title_content);
}

function brighter_editor_pick_customizer_quick_edit() {
    // Retrieve the updated title from the Customizer setting.
    $news_title_content = get_theme_mod('editor_pick_section_title', __('Editor Pick', 'brighter-blog'));

    // Return the updated title.
    return esc_html($news_title_content);
}


function brighter_blog_trending_post_customizer_quick_edit() {
    // Retrieve the updated title from the Customizer setting.
    $news_title_content = get_theme_mod('trending_post_section_title', __('Trending', 'brighter-blog'));

    // Return the updated title.
    return esc_html($news_title_content);
}

function brighter_blog_trending_video_customizer_quick_edit() {
    // Retrieve the updated title from the Customizer setting.
    $news_title_content = get_theme_mod('video_section_title', __('Trending Video', 'brighter-blog'));

    // Return the updated title.
    return esc_html($news_title_content);
}
function brighter_blog_in_focus_customizer_quick_edit() {
    // Retrieve the updated title from the Customizer setting.
    $news_title_content = get_theme_mod('in_focus_section_title', __('In Focus', 'brighter-blog'));

    // Return the updated title.
    return esc_html($news_title_content);
}
function brighter_blog_copyright_customizer_quick_edit() {
    // Retrieve the updated title from the Customizer setting.

    $copyRight = get_theme_mod('copyright_setting', __('© Copyright 2014-[Y] mycodecare.com. All rights reserved.', 'brighter-blog'));
    $copyRight = str_replace("[Y]",date("Y"),$copyRight);

    // Return the updated title.
    return esc_html($copyRight);
}
