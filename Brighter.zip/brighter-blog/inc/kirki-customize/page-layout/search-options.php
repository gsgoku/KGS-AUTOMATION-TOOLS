<?php
new \Kirki\Section(
	'search_options',
	[
		'title'       => esc_html__( 'Search Page Options', 'brighter-blog' ),
		'panel'       => 'news_page_layout_settings',
		'priority'    => 4,
	]
);
new \Kirki\Field\Select(
	[
		'settings'    => 'search_layout',
		'label'       => esc_html__( 'Select An Option', 'brighter-blog' ),
		'section'     => 'search_options',
		'default'     => 'rtl',
		'placeholder' => esc_html__( 'Choose An Option', 'brighter-blog' ),
		'choices'     => [
			'rtl' => esc_html__( 'Right Sidebar', 'brighter-blog' ),
			'ltl' => esc_html__( 'Left Sidebar', 'brighter-blog' ),
			'no-sidebar' => esc_html__( 'No Sidebar', 'brighter-blog' ),
		],
	]
);