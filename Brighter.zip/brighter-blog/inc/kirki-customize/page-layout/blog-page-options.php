<?php
kirki::add_section( 'news_page_options', array(
	'title'    => esc_html__( 'Page Options', 'brighter-blog' ),
	'panel'    => 'news_page_layout_settings',
	'priority'    => 1,
	) );

new \Kirki\Field\Select(
	[
		'settings'    => 'page_layout',
		'label'       => esc_html__( 'Select An Option', 'brighter-blog' ),
		'section'     => 'news_page_options',
		'default'     => 'rtl',
		'placeholder' => esc_html__( 'Choose An option', 'brighter-blog' ),
		'choices'     => [
			'rtl' => esc_html__( 'Right Sidebar', 'brighter-blog' ),
			'ltl' => esc_html__( 'Left Sidebar', 'brighter-blog' ),
			'no-sidebar' => esc_html__( 'No Sidebar', 'brighter-blog' ),
		],
	]
);