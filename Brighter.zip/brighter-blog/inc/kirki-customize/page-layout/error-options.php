<?php
new \Kirki\Section(
	'error_options',
	[
		'title'       => esc_html__( 'Error Page Options', 'brighter-blog' ),
		'panel'       => 'news_page_layout_settings',
		'priority'    => 5,
	]
);

new \Kirki\Field\Select(
	[
		'settings'    => 'error_layout',
		'label'       => esc_html__( 'Select An Option', 'brighter-blog' ),
		'section'     => 'error_options',
		'default'     => 'rtl',
		'placeholder' => esc_html__( 'Choose An option', 'brighter-blog' ),
		'choices'     => [
			'rtl' => esc_html__( 'Right Sidebar', 'brighter-blog' ),
			'ltl' => esc_html__( 'Left Sidebar', 'brighter-blog' ),
			'no-sidebar' => esc_html__( 'No Sidebar', 'brighter-blog' ),
		],
	]
);