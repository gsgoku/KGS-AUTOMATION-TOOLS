<?php
new \Kirki\Section(
	'singe_page_options',
	[
		'title'       => esc_html__( 'Single Page Options', 'brighter-blog' ),
		'panel'       => 'news_page_layout_settings',
		'priority'    => 2,
	]
);

new \Kirki\Field\Select(
	[
		'settings'    => 'singe_page_layout',
		'label'       => esc_html__( 'Select An Option', 'brighter-blog' ),
		'section'     => 'singe_page_options',
		'default'     => 'rtl',
		'placeholder' => esc_html__( 'Choose An option', 'brighter-blog' ),
		'choices'     => [
			'rtl' => esc_html__( 'Right Sidebar', 'brighter-blog' ),
			'ltl' => esc_html__( 'Left Sidebar', 'brighter-blog' ),
			'no-sidebar' => esc_html__( 'No Sidebar', 'brighter-blog' ),
		],
	]
);