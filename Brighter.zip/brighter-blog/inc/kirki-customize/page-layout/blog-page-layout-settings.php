<?php
Kirki::add_panel( 'news_page_layout_settings', array(
    'title'    => esc_html__( 'Page & Layout', 'brighter-blog' ),
    'priority' => 5
) );
