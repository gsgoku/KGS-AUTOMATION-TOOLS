<?php
new \Kirki\Section(
    'shop_page_options',
    [
        'title' => esc_html__('Shop Page Options', 'brighter-blog'),
        'panel' => 'news_page_layout_settings',
        'priority' => 5,
    ]
);

new \Kirki\Field\Select(
    [
        'settings' => 'shop_page_layout',
        'label' => esc_html__('Select An Option', 'brighter-blog'),
        'description' => esc_html__( 'Select Shop page sidebar', 'brighter-blog' ),
        'section' => 'shop_page_options',
        'default' => 'rtl',
        'placeholder' => esc_html__('Choose An Option', 'brighter-blog'),
        'choices' => [
            'rtl' => esc_html__('Right Sidebar', 'brighter-blog'),
            'ltl' => esc_html__('Left Sidebar', 'brighter-blog'),
            'no-sidebar' => esc_html__('No Sidebar', 'brighter-blog'),
        ],
    ]
);

new \Kirki\Field\Select(
    [
        'settings' => 'single_shop_page_layout',
        'label' => esc_html__('Select An Option', 'brighter-blog'),
        'description' => esc_html__( 'Select shop\'s single page sidebar', 'brighter-blog' ),
        'section' => 'shop_page_options',
        'default' => 'rtl',
        'placeholder' => esc_html__('Choose An Option', 'brighter-blog'),
        'choices' => [
            'rtl' => esc_html__('Right Sidebar', 'brighter-blog'),
            'ltl' => esc_html__('Left Sidebar', 'brighter-blog'),
            'no-sidebar' => esc_html__('No Sidebar', 'brighter-blog'),
        ],
    ]
);