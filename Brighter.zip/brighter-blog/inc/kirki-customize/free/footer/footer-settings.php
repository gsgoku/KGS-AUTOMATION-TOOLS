<?php
Kirki::add_panel( 'footer_options', array(
    'title'    => esc_html__( 'Footer Options', 'brighter-blog' ),
    'priority' => 2
) );

/**
 * Start Select Footer
 */
Kirki::add_section( 'select_footer_options', array(
    'title'    => esc_html__( 'Footer Select', 'brighter-blog' ),
    'panel'    => 'footer_options',
) );

// footer_enable disable
new \Kirki\Field\Checkbox_Switch(
    [
        'settings'    => 'footer_enable',
        'description'       => esc_html__( 'Enable/Disable Footer', 'brighter-blog' ),
        'section'     => 'select_footer_options',
        'default'     => 'on',
        'choices'     => [
            'on'  => esc_html__( 'Enable', 'brighter-blog' ),
            'off' => esc_html__( 'Disable', 'brighter-blog' ),
        ],
        
    ]
);

Kirki::add_field( 'theme_config', [
    'type'        => 'radio_image',
    'settings'    => 'select_footer',
    'label'       => esc_html__( 'Select Footer', 'brighter-blog' ),
    'section'     => 'select_footer_options',
    'default'     => 'one',
    'choices'     => [
			'one' => get_template_directory_uri() . '/assets/images/footer1.png',
		],
    'active_callback' => [
            [
                'setting'  => 'footer_enable',
                'operator' => '==',
                'value'    => true,
            ],
        ],
] );