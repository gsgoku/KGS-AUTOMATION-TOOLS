<?php
Kirki::add_section( 'header_middle_section', array(
	'title'    => esc_html__( 'Header Middle', 'brighter-blog' ),
	'panel'    => 'header_options',
) );

//Middle Header enable disable
new \Kirki\Field\Checkbox_Switch(
	[
		'description'       => esc_html__( 'Enable/Disable Header Middle', 'brighter-blog' ),
		'section'     => 'header_middle_section',
		'settings' => 'header_middle_enable',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'sticky_header_enable',
		'label'       => esc_html__( 'Enable Sticky Header', 'brighter-blog' ),
		'section'     => 'header_middle_section',
		'default'     => 'on',

		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
		'active_callback' => [
			[
				'setting'  => 'header_middle_enable',
				'operator' => '==',
				'value'    => true,
			]
		],
	]
);
// Middle header Bg color
new \Kirki\Field\Color(
	[

		'label'       => __( 'Header Top Background', 'brighter-blog' ),
		'description' => esc_html__( 'Add Header Middle Background Color', 'brighter-blog' ),
		'section'     => 'header_middle_section',
		'transport' => 'auto',
		'default'   => '#fff',
		'active_callback' => [
			[
				'setting'  => 'header_middle_enable',
				'operator' => '==',
				'value'    => true,
			]
		],
		'output' => array(
			array(
				'element'  => '.header-layout1 .header-middle',
				'property' => 'background',
			),
		),
	]
);



//Dark Light enable disable
new \Kirki\Field\Checkbox_Switch(
	[
		'description'       => esc_html__( 'Enable/Disable Dark Light', 'brighter-blog' ),
		'section'     => 'header_middle_section',
		'settings' => 'enable_light_dark_section',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
        'active_callback' => [
			[
				'setting'  => 'header_middle_enable',
				'operator' => '==',
				'value'    => true,
			]
		],
	]
);