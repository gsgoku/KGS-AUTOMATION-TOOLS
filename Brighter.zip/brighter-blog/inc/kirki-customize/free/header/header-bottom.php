<?php
Kirki::add_section( 'header_bottom_section', array(
	'title'    => esc_html__( 'Header Bottom', 'brighter-blog' ),
	'panel'    => 'header_options',
) );

new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'header_bottom_enable',
		'description'       => esc_html__( 'Enable/Disable Middle Header', 'brighter-blog' ),
		'section'     => 'header_bottom_section',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);


//Hide show ads
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'header_ads_enable',
		'label'       => esc_html__( 'Enable Ads Section', 'brighter-blog' ),
		'section'     => 'header_bottom_section',
		'default'     => 'on',
		'active_callback' => [
			[
				'setting'  => 'header_bottom_enable',
				'operator' => '==',
				'value'    => true,
			]
		],
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);


new \Kirki\Field\Image(
	[
		'settings'    => 'header_ads_image',
		'label'       => esc_html__( 'Header Ad Image', 'brighter-blog' ),
		'description' => esc_html__( 'Ads images recommended size (615 x 69 Px)', 'brighter-blog' ),
		'section'     => 'header_bottom_section',
		'active_callback' => [
			[
				'setting'  => 'header_bottom_enable',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'header_ads_enable',
				'operator' => '==',
				'value'    => true,
			]
		],
		'default'     => get_template_directory_uri() . '/assets/images/ads/ads-1.jpg',
	]
);

new \Kirki\Field\URL(
	[
		'settings' => 'header_ads_image_url',
		'label'    => esc_html__( 'Ads url', 'brighter-blog' ),
		'section'  => 'header_bottom_section',
		'default'  => '#',
		'active_callback' => [
			[
				'setting'  => 'header_bottom_enable',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'header_ads_enable',
				'operator' => '==',
				'value'    => true,
			]
		],
	]
);

