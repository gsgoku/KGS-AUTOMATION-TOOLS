<?php
Kirki::add_section( 'header_top_section', array(
	'title'    => esc_html__( 'Header Top', 'brighter-blog' ),
	'panel'    => 'header_options',
) );

//Top Header enable disable
new \Kirki\Field\Checkbox_Switch(
	[
		'description'       => esc_html__( 'Enable/Disable Top Header', 'brighter-blog' ),
		'section'     => 'header_top_section',
		'settings' => 'enable_top_header',
		'default'     => 'on',
		'priority'    => 2,
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

// Top header Bg color
new \Kirki\Field\Color(
	[
		'label'       => __( 'Header Top Background', 'brighter-blog' ),
		'description' => esc_html__( 'Add Header Top Background Color', 'brighter-blog' ),
		'section'     => 'header_top_section',
		'transport' => 'auto',
		'default'   => '#fff',
		'priority'    => 3,
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			]
		],
		'output' => array(
			array(
				'element'  => '.header-layout1 .header-top',
				'property' => 'background',
			),
		),
	]
);



//Header Top Left Side Hide/Show
new \Kirki\Field\Checkbox_Switch(
	[

		'label'       => esc_html__( 'Enable Left Section', 'brighter-blog' ),
		'section'     => 'header_top_section',
		'settings' => 'enable_top_header_left_side',
		'default'     => 'on',
		'priority'    => 4,
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'select_header',
				'operator' => '==',
				'value'    => 'one',
			]
		],
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

//Hide show social media
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'header_social_enable',
		'label'       => esc_html__( 'Enable Social Media', 'brighter-blog' ),
		'section'     => 'header_top_section',
		'default'     => 'on',
		'priority'    => 5,
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'enable_top_header_left_side',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'select_header',
				'operator' => '==',
				'value'    => 'one',
			]
		],
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);


new \Kirki\Field\Repeater(
	[
		'settings' => 'header_social_media_icon',
		'label'    => esc_html__( 'Add Social Media', 'brighter-blog' ),
		'section'  => 'header_top_section',
		'priority'    => 6,
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'header_social_enable',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'enable_top_header_left_side',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'select_header',
				'operator' => '==',
				'value'    => 'one',
			]
		],
		'choices' => [
			'limit' => 2,
		],
		'default'  => [
			[
				'link_url'    => 'https://facebook.com/',
				'social_icon' => 'fa-brands fa-facebook-f',


			],
			[
				'link_url'    => 'https://x.com/',
				'social_icon' => 'fa-brands fa-x-twitter',


			],
		],
		'fields'   => [
			'title'    => [
				'type'        => 'text',
				'label'       => esc_html__( 'Title', 'brighter-blog' ),
				'description' => esc_html__( 'Add title of social media', 'brighter-blog' ),
				'default'     => 'Facebook',
			],

			'link_url'    => [
				'type'        => 'url',
				'label'       => esc_html__( 'Link', 'brighter-blog' ),
				'description' => esc_html__( 'Add link of social media', 'brighter-blog' ),
				'default'     => '#',
			],

			'social_icon' => [
				'type'        => 'select',
				'label'       => esc_html__( 'Select Icon', 'brighter-blog' ),
				'description' => esc_html__( 'Select Social Media Icon', 'brighter-blog' ),
				'default'     => 'fab fa-facebook-f',
				'choices' => [
					'fa-brands fa-facebook-f'     => esc_attr__( 'Facebook', 'brighter-blog' ),
					'fa-brands fa-x-twitter'        => esc_attr__( 'X', 'brighter-blog' ),
					'fa-brands fa-linkedin-in'    => esc_attr__( 'LinkedIn', 'brighter-blog' ),
					'fa-brands fa-instagram'      => esc_attr__( 'Instagram', 'brighter-blog' ),
					'fa-brands fa-pinterest'      => esc_attr__( 'Pinterest', 'brighter-blog' ),
					'fa-brands fa-dribbble'       => esc_attr__( 'Dribbble', 'brighter-blog' ),
					'fa-brands fa-behance'        => esc_attr__( 'Behance', 'brighter-blog' ),
					'fa-brands fa-tiktok'         => esc_attr__( 'TikTok', 'brighter-blog' ),
					'fa-brands fa-snapchat'       => esc_attr__( 'Snapchat', 'brighter-blog' ),
					'fa-brands fa-youtube'        => esc_attr__( 'YouTube', 'brighter-blog' ),
					'fa-brands fa-weixin'         => esc_attr__( 'WeChat', 'brighter-blog' ),
					'fa-brands fa-telegram'       => esc_attr__( 'Telegram', 'brighter-blog' ),
					'fa-brands fa-reddit'         => esc_attr__( 'Reddit', 'brighter-blog' ),
					'fa-brands fa-quora'          => esc_attr__( 'Quora', 'brighter-blog' ),
					'fa-brands fa-discord'        => esc_attr__( 'Discord', 'brighter-blog' ),
					'fa-brands fa-whatsapp'       => esc_attr__( 'WhatsApp', 'brighter-blog' ),
				],

				'icon_color'    => [
					'type'        => 'color',
					'label'       => esc_html__( 'Icon Color', 'brighter-blog' ),
					'description' => esc_html__( 'Add Social Icon Color', 'brighter-blog' ),
					'alpha'       => true,
					'transport'   => 'auto',
				],
				'color'    => [
					'type'        => 'color',
					'label'       => esc_attr__( 'Color', 'brighter-blog' ),
					'description' => esc_attr__( 'Pick a color', 'brighter-blog' ),
					'default'     => '#000000', // Default color value
				],
			],
		],
	]
);
Kirki::add_field( 'theme_config', [
    'type'        => 'custom',
    'settings'    => 'header_top_social_icon_pro_feature_upgrade',
    'section'     => 'header_top_section',
	'priority'    => 7,
    'default'     => '
        <div style="text-align: center; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
            <h3 style="margin-bottom: 10px;">' . esc_html__( 'Upgrade to Pro!', 'brighter-blog' ) . '</h3>
            <p style="margin-bottom: 15px;">' . esc_html__( 'Unlock exclusive features and customization options by upgrading to the Pro version.', 'brighter-blog' ) . '</p>
            <img src="' . esc_url( get_template_directory_uri() . '/assets/images/free/header-top-pro.png' ) . '" alt="' . esc_attr__( 'Pro Feature', 'brighter-blog' ) . '" style="max-width: 100%; border-radius: 10px; margin-bottom: 15px;" />
            <a href="'.esc_url(brighter_blog_purchase_link()).'" target="_blank" style="display: inline-block; padding: 10px 20px; background-color: #6c63ff; color: #fff; text-decoration: none; border-radius: 5px; font-weight: bold;">' . esc_html__( 'Upgrade Now', 'brighter-blog' ) . '</a>
        </div>
    ',
] );
//Header Top Middle Section Hide/Show
new \Kirki\Field\Checkbox_Switch(
	[

		'label'       => esc_html__( 'Enable Middle Section', 'brighter-blog' ),
		'section'     => 'header_top_section',
		'settings' => 'enable_header_top_middle_side',
		'default'     => 'on',
		'priority'    => 8,
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'select_header',
				'operator' => '==',
				'value'    => 'one',
			]
		],
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);




//Header Top Right Side Hide/Show
new \Kirki\Field\Checkbox_Switch(
	[

		'label'       => esc_html__( 'Enable Right Section', 'brighter-blog' ),
		'section'     => 'header_top_section',
		'settings' => 'enable_header_top_right_side',
		'default'     => 'on',
		'priority'    => 9,
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'select_header',
				'operator' => '==',
				'value'    => 'one',
			]
		],
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

//Search Hide/Show
new \Kirki\Field\Checkbox_Switch(
	[

		'label'       => esc_html__( 'Enable Search Button', 'brighter-blog' ),
		'section'     => 'header_top_section',
		'settings' => 'enable_search_section',
		'default'     => 'on',
		'priority'    => 10,
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'enable_header_top_right_side',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'select_header',
				'operator' => '==',
				'value'    => 'one',
			]
		],
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

//Right Section End




//===================== Header Two Code Starts ==================



//Header Top Left Side Hide/Show
new \Kirki\Field\Checkbox_Switch(
	[

		'label'       => esc_html__( 'Enable Left Section', 'brighter-blog' ),
		'section'     => 'header_top_section',
		'settings' => 'header_two_enable_top_header_left_side',
		'default'     => 'on',
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'select_header',
				'operator' => '==',
				'value'    => 'two',
			]
		],
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);
//Date Hide/Show
new \Kirki\Field\Checkbox_Switch(
	[

		'label'       => esc_html__( 'Enable Date and Day', 'brighter-blog' ),
		'section'     => 'header_top_section',
		'settings' => 'header_two_date_time_section',
		'default'     => 'on',
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'header_two_enable_top_header_left_side',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'select_header',
				'operator' => '==',
				'value'    => 'two',
			]
		],
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);


//Header Top Middle Section Hide/Show
new \Kirki\Field\Checkbox_Switch(
	[

		'label'       => esc_html__( 'Enable Middle Section', 'brighter-blog' ),
		'section'     => 'header_top_section',
		'settings' => 'header_two_enable_header_top_middle_side',
		'default'     => 'on',
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'select_header',
				'operator' => '==',
				'value'    => 'two',
			]
		],
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);




//Header Top Right Side Hide/Show
new \Kirki\Field\Checkbox_Switch(
	[

		'label'       => esc_html__( 'Enable Right Section', 'brighter-blog' ),
		'section'     => 'header_top_section',
		'settings' => 'header_two_enable_header_top_right_side',
		'default'     => 'on',
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'select_header',
				'operator' => '==',
				'value'    => 'two',
			]
		],
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);


//Hide show social media
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'header_two_header_social_enable',
		'label'       => esc_html__( 'Enable Social Media', 'brighter-blog' ),
		'section'     => 'header_top_section',
		'default'     => 'on',
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'header_two_enable_header_top_right_side',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'select_header',
				'operator' => '==',
				'value'    => 'two',
			]
		],
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);


new \Kirki\Field\Repeater(
	[
		'settings' => 'header_two_social_media_icon',
		'label'    => esc_html__( 'Add Social Media', 'brighter-blog' ),
		'section'  => 'header_top_section',
		'active_callback' => [
			[
				'setting'  => 'enable_top_header',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'header_two_header_social_enable',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'header_two_enable_header_top_right_side',
				'operator' => '==',
				'value'    => true,
			],
			[
				'setting'  => 'select_header',
				'operator' => '==',
				'value'    => 'two',
			]
		],
		'choices' => [
			'limit' => 2,
		],
		'default'  => [
			[
				'link_url'    => 'https://facebook.com/',
				'social_icon' => 'fa-brands fa-facebook-f',


			],
			[
				'link_url'    => 'https://x.com/',
				'social_icon' => 'fa-brands fa-x-twitter',


			],
		],
		'fields'   => [
			'title'    => [
				'type'        => 'text',
				'label'       => esc_html__( 'Title', 'brighter-blog' ),
				'description' => esc_html__( 'Add title of social media', 'brighter-blog' ),
				'default'     => 'Facebook',
			],

			'link_url'    => [
				'type'        => 'url',
				'label'       => esc_html__( 'Link', 'brighter-blog' ),
				'description' => esc_html__( 'Add link of social media', 'brighter-blog' ),
				'default'     => '#',
			],

			'social_icon' => [
				'type'        => 'select',
				'label'       => esc_html__( 'Select Icon', 'brighter-blog' ),
				'description' => esc_html__( 'Select Social Media Icon', 'brighter-blog' ),
				'default'     => 'fab fa-facebook-f',
				'choices' => [
					'fa-brands fa-facebook-f'     => esc_attr__( 'Facebook', 'brighter-blog' ),
					'fa-brands fa-x-twitter'        => esc_attr__( 'X', 'brighter-blog' ),
					'fa-brands fa-linkedin-in'    => esc_attr__( 'LinkedIn', 'brighter-blog' ),
					'fa-brands fa-instagram'      => esc_attr__( 'Instagram', 'brighter-blog' ),
					'fa-brands fa-pinterest'      => esc_attr__( 'Pinterest', 'brighter-blog' ),
					'fa-brands fa-dribbble'       => esc_attr__( 'Dribbble', 'brighter-blog' ),
					'fa-brands fa-behance'        => esc_attr__( 'Behance', 'brighter-blog' ),
					'fa-brands fa-tiktok'         => esc_attr__( 'TikTok', 'brighter-blog' ),
					'fa-brands fa-snapchat'       => esc_attr__( 'Snapchat', 'brighter-blog' ),
					'fa-brands fa-youtube'        => esc_attr__( 'YouTube', 'brighter-blog' ),
					'fa-brands fa-weixin'         => esc_attr__( 'WeChat', 'brighter-blog' ),
					'fa-brands fa-telegram'       => esc_attr__( 'Telegram', 'brighter-blog' ),
					'fa-brands fa-reddit'         => esc_attr__( 'Reddit', 'brighter-blog' ),
					'fa-brands fa-quora'          => esc_attr__( 'Quora', 'brighter-blog' ),
					'fa-brands fa-discord'        => esc_attr__( 'Discord', 'brighter-blog' ),
					'fa-brands fa-whatsapp'       => esc_attr__( 'WhatsApp', 'brighter-blog' ),
				],

				'icon_color'    => [
					'type'        => 'color',
					'label'       => esc_html__( 'Icon Color', 'brighter-blog' ),
					'description' => esc_html__( 'Add Social Icon Color', 'brighter-blog' ),
					'alpha'       => true,
					'transport'   => 'auto',
				],
				'color'    => [
					'type'        => 'color',
					'label'       => esc_attr__( 'Color', 'brighter-blog' ),
					'description' => esc_attr__( 'Pick a color', 'brighter-blog' ),
					'default'     => '#000000', // Default color value
				],
			],
		],
	]
);
//Right Section End

