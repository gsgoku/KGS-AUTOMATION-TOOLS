<?php
Kirki::add_section( 'Blog_options', array(
	'title' => esc_html__( 'Blog Options', 'brighter-blog' ),
	'panel' => 'brighter_blog_option_layout',
) );

new \Kirki\Field\Select(
	[
		'settings' => 'blog_layout',
		'label'    => esc_html__( 'Select Blog Page Layout', 'brighter-blog' ),
		'section'  => 'Blog_options',
		'default'  => 'right-sidebar',
		'choices'  => [
			'full-width'    => esc_html__( 'Full Width', 'brighter-blog' ),
			'left-sidebar'  => esc_html__( 'Left Sidebar', 'brighter-blog' ),
			'right-sidebar' => esc_html__( 'Right Sidebar', 'brighter-blog' ),
			'grid'          => esc_html__( 'Grid Full', 'brighter-blog' ),
			'grid-ls'       => esc_html__( 'Grid With Left Sidebar', 'brighter-blog' ),
			'grid-rs'       => esc_html__( 'Grid With Right Sidebar', 'brighter-blog' ),
		],
	]
);


new \Kirki\Field\Select(
	[
		'settings' => 'blog_title_tag',
		'label'    => esc_html__( 'Select Blog Title Tag', 'brighter-blog' ),
		'section'  => 'Blog_options',
		'default'  => 'h2',
		'choices'  => [
			'h1'    => esc_html__( 'H1', 'brighter-blog' ),
			'h2'    => esc_html__( 'H2', 'brighter-blog' ),
			'h3'    => esc_html__( 'H3', 'brighter-blog' ),
			'h4'    => esc_html__( 'H4', 'brighter-blog' ),
			'h5'    => esc_html__( 'H5', 'brighter-blog' ),
			'h6'    => esc_html__( 'H6', 'brighter-blog' ),
			'p'    	=> esc_html__( 'p', 'brighter-blog' ),
			'span'  => esc_html__( 'Span', 'brighter-blog' ),
		],
	]
);

// Select Category 
new \Kirki\Field\Select(
    [
        'settings'    => 'blog_post_category',
        'label'       => esc_html__( 'Select Category ', 'brighter-blog' ),
        'section'     => 'Blog_options',
        'default'     => array(1),
        'placeholder' => esc_html__( 'Choose An Category', 'brighter-blog' ),
        'multiple'    => -1,
        'choices'     => Kirki\Util\Helper::get_terms(array('taxonomy' => 'category')),
        'active_callback' => [
            [
                'setting'  => 'enable_blog_post',
                'operator' => '==',
                'value'    => true,
            ],
           
        ]
    ]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings' => 'enable_image',
		'label'    => esc_html__( 'Enable Image', 'brighter-blog' ),
		'section'  => 'Blog_options',
		'default'  => 'on',
		'choices'  => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings' => 'enable_title',
		'label'    => esc_html__( 'Enable Title', 'brighter-blog' ),
		'section'  => 'Blog_options',
		'default'  => 'on',
		'choices'  => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);
new \Kirki\Field\Checkbox_Switch(
	[
		'settings' => 'enable_dec',
		'label'    => esc_html__( 'Enable Content', 'brighter-blog' ),
		'section'  => 'Blog_options',
		'default'  => 'on',
		'choices'  => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings' => 'enable_author',
		'label'    => esc_html__( 'Enable Author Name', 'brighter-blog' ),
		'section'  => 'Blog_options',
		'default'  => 'on',
		'choices'  => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings' => 'enable_date',
		'label'    => esc_html__( 'Enable Date', 'brighter-blog' ),
		'section'  => 'Blog_options',
		'default'  => 'on',
		'choices'  => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings' => 'enable_comment',
		'label'    => esc_html__( 'Enable Comment', 'brighter-blog' ),
		'section'  => 'Blog_options',
		'default'  => 'on',
		'choices'  => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings' => 'enable_cats',
		'label'    => esc_html__( 'Enable Category', 'brighter-blog' ),
		'section'  => 'Blog_options',
		'default'  => 'on',
		'choices'  => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings' => 'enable_tags',
		'label'    => esc_html__( 'Enable Tag', 'brighter-blog' ),
		'section'  => 'Blog_options',
		'default'  => 'on',
		'choices'  => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings' => 'enable_btn',
		'label'    => esc_html__( 'Enable Read More', 'brighter-blog' ),
		'section'  => 'Blog_options',
		'default'  => 'on',
		'choices'  => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Text(
	[
		'settings'        => 'btn_text',
		'label'           => esc_html__( 'Button Text', 'brighter-blog' ),
		'section'         => 'Blog_options',
		'default'         => esc_html__( 'Continue reading', 'brighter-blog' ),
		'active_callback' => [
			[
				'setting'  => 'enable_btn',
				'operator' => '==',
				'value'    => true,
			],
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings' => 'enable_pagination',
		'label'    => esc_html__( 'Enable Pagination', 'brighter-blog' ),
		'section'  => 'Blog_options',
		'default'  => 'on',
		'choices'  => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Radio_Buttonset(
	[
		'settings'        => 'pagination_alignment',
		'label'           => esc_html__( 'Pagination Alignment', 'brighter-blog' ),
		'section'         => 'Blog_options',
		'default'         => 'left',
		'choices'         => [
			'left'   => esc_html__( 'Left', 'brighter-blog' ),
			'center' => esc_html__( 'Center', 'brighter-blog' ),
			'right'  => esc_html__( 'Right', 'brighter-blog' ),
		],
		'active_callback' => [
			[
				'setting'  => 'enable_pagination',
				'operator' => '==',
				'value'    => true,
			],
		],
		'transport'       => 'auto',
		'output'          => array(
			array(
				'element'  => 'nav.navigation.pagination',
				'property' => 'text-align',
			),
		),
	]
);