<?php
Kirki::add_section( 'shop_options', array(
	'title' => esc_html__( 'Shop Page Options', 'brighter-blog' ),
	'panel' => 'brighter_blog_theme_shop',
) );

new \Kirki\Field\Select(
	[
		'settings' => 'shop_page_layout',
		'label'    => esc_html__( 'Select Shop Page Layout', 'brighter-blog' ),
		'section'  => 'shop_options',
		'default'  => 'full-width',
		'choices'  => [
			'full-width'    => esc_html__( 'No Sidebar', 'brighter-blog' ),
			'left-sidebar'  => esc_html__( 'Left Sidebar', 'brighter-blog' ),
			'right-sidebar' => esc_html__( 'Right Sidebar', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Select(
	[
		'settings' => 'shop_columns',
		'label'    => esc_html__( 'Select Shop Item Columns', 'brighter-blog' ),
		'section'  => 'shop_options',
		'default'  => '3',
		'choices'  => [
			'1'    => esc_html__( 'One Column', 'brighter-blog' ),
			'2'    => esc_html__( 'Two Column', 'brighter-blog' ),
			'3'    => esc_html__( 'Three Column', 'brighter-blog' ),
			'4'    => esc_html__( 'Four Column', 'brighter-blog' ),
			'5'    => esc_html__( 'Five Column', 'brighter-blog' ),
			'6'    => esc_html__( 'Six Column', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Number(
	[
		'settings' => 'shop_perpage',
		'label'    => esc_html__( 'Display Item', 'brighter-blog' ),
		'section'  => 'shop_options',
		'default'  => 6,
		'choices'  => [
			'min'  => 1,
			'max'  => 10,
			'step' => 1,
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'shop_enable_filter',
		'label'       => esc_html__( 'Enable Filter', 'brighter-blog' ),
		'description' => esc_html__( 'Enable Shop Page Filter Options', 'brighter-blog' ),
		'section'     => 'shop_options',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'shop_enable_minicart',
		'label'       => esc_html__( 'Enable Header Mini Cart', 'brighter-blog' ),
		'description' => esc_html__( 'Enable Mini Cart On Header', 'brighter-blog' ),
		'section'     => 'shop_options',
		'default'     => 'off',
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);