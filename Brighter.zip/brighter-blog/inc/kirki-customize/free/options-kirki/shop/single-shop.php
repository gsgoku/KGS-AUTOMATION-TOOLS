<?php
Kirki::add_section( 'single_shop_options', array(
	'title' => esc_html__( 'Single Shop Page', 'brighter-blog' ),
	'panel' => 'brighter_blog_theme_shop',
) );

new \Kirki\Field\Select(
	[
		'settings' => 'single_shop_page_layout',
		'label'    => esc_html__( 'Select Single Shop Page Layout', 'brighter-blog' ),
		'section'  => 'single_shop_options',
		'default'  => 'full-width',
		'choices'  => [
			'full-width'    => esc_html__( 'No Sidebar', 'brighter-blog' ),
			'left-sidebar'  => esc_html__( 'Left Sidebar', 'brighter-blog' ),
			'right-sidebar' => esc_html__( 'Right Sidebar', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Select(
	[
		'settings' => 'related_item_columns',
		'label'    => esc_html__( 'Select Related Item Columns', 'brighter-blog' ),
		'section'  => 'single_shop_options',
		'default'  => '4',
		'choices'  => [
			'1'    => esc_html__( 'One Column', 'brighter-blog' ),
			'2'    => esc_html__( 'Two Column', 'brighter-blog' ),
			'3'    => esc_html__( 'Three Column', 'brighter-blog' ),
			'4'    => esc_html__( 'Four Column', 'brighter-blog' ),
			'5'    => esc_html__( 'Five Column', 'brighter-blog' ),
			'6'    => esc_html__( 'Six Column', 'brighter-blog' ),
		],
	]
);

new \Kirki\Field\Number(
	[
		'settings' => 'related_shop_perpage',
		'label'    => esc_html__( 'Display Item', 'brighter-blog' ),
		'section'  => 'single_shop_options',
		'default'  => 4,
		'choices'  => [
			'min'  => 1,
			'max'  => 10,
			'step' => 1,
		],
	]
);