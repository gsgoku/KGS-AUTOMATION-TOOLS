<?php
Kirki::add_panel( 'brighter_blog_theme_shop', array(
	'title'    => esc_html__( 'Shop Options', 'brighter-blog' ),
	'priority' => 11
) );