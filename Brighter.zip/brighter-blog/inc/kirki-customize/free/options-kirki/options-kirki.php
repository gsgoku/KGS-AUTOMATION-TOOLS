<?php
Kirki::add_panel( 'brighter_blog_theme_options', array(
    'title'    => esc_html__( 'Theme Setting Option', 'brighter-blog' ),
    'priority' => 3
) );