<?php
new \Kirki\Section( 'hero_post_options', array(
    'title'    => esc_html__( 'Hero Post', 'brighter-blog' ),
    'panel'    => 'font-page-settings',
    ) );

//News Main Section enable disable
new \Kirki\Field\Checkbox_Switch(
    [
        'description'       => esc_html__( 'Enable Hero', 'brighter-blog' ),
        'section'     => 'hero_post_options',
        'settings'    => 'enable_hero_post',
        'default'     => 'on',
        'choices'     => [
            'on'  => esc_html__( 'Enable', 'brighter-blog' ),
            'off' => esc_html__( 'Disable', 'brighter-blog' ),
        ],
    ]
);

    
new \Kirki\Field\Text(
    [
        'settings' => 'hero_section_title',
        'label'    => esc_html__( '', 'brighter-blog' ),
        'default'     => '',
        'section'  => 'hero_post_options',
        'active_callback' => [
            [
                'setting'  => 'enable_hero_post',
                'operator' => '==',
                'value'    => true,
            ],
        ],
    ]
);

// Hero Bg color
new \Kirki\Field\Color(
	[

		'label'       => __( 'Hero Background Color', 'brighter-blog' ),
		'description' => esc_html__( 'Add Hero Background Color', 'brighter-blog' ),
		'section'     => 'hero_post_options',
		'transport' => 'auto',
		'default'   => '#F9FAFB',
		'active_callback' => [
			[
				'setting'  => 'enable_hero_post',
				'operator' => '==',
				'value'    => true,
			]
		],
		'output' => array(
			array(
				'element'  => '.hero-post .post-preview',
				'property' => 'background',
                'suffix'   => ' !important',
			),
		),
	]
);


// Toggle Field: Choose between Category or Latest Post
new \Kirki\Field\Radio(
    [
        'settings'    => 'hero_post_choose_cat_or_latest',
        'label'       => esc_html__( 'Select Content Type', 'brighter-blog' ),
        'section'     => 'hero_post_options',
        'default'     => 'latest',

        'choices'     => [
            'latest'     => esc_html__( 'Latest Post', 'brighter-blog' ),
        ],
        'active_callback' => [
            [
                'setting'  => 'enable_hero_post',
                'operator' => '==',
                'value'    => true,
            ],
        ],
    ]
);

Kirki::add_field( 'theme_config', [
    'type'        => 'custom',
    'settings'    => 'hero_pro_feature_upgrade',
    'section'     => 'hero_post_options',
    'default'     => '
        <div style="text-align: center; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
            <h3 style="margin-bottom: 10px;">' . esc_html__( 'Upgrade to Pro!', 'brighter-blog' ) . '</h3>
            <p style="margin-bottom: 15px;">' . esc_html__( 'Unlock exclusive features and customization options by upgrading to the Pro version.', 'brighter-blog' ) . '</p>
            <img src="' . esc_url( get_template_directory_uri() . '/assets/images/free/hero.png' ) . '" alt="' . esc_attr__( 'Pro Feature', 'brighter-blog' ) . '" style="max-width: 100%; border-radius: 10px; margin-bottom: 15px;" />
            <a href="'.esc_url(brighter_blog_purchase_link()).'" target="_blank" style="display: inline-block; padding: 10px 20px; background-color: #6c63ff; color: #fff; text-decoration: none; border-radius: 5px; font-weight: bold;">' . esc_html__( 'Upgrade Now', 'brighter-blog' ) . '</a>
        </div>
    ',
    'active_callback' => [
        [
            'setting'  => 'enable_hero_post',
            'operator' => '==',
            'value'    => true,
        ],
    ],
] );

  