<?php
/**
* Start Top Category
*/

kirki::add_section( 'top_category_options', array(
'title'    => esc_html__( 'Top Category', 'brighter-blog' ),
'panel'    => 'font-page-settings',
) );


// Top Category enable disable
new \Kirki\Field\Checkbox_Switch(
    [
        'label'       => esc_html__( 'Enable Top Category', 'brighter-blog' ),
        'section'     => 'top_category_options',
        'settings' => 'top_category_enable',
        'default'     => 'on',
        'choices'     => [
            'on'  => esc_html__( 'Enable', 'brighter-blog' ),
            'off' => esc_html__( 'Disable', 'brighter-blog' ),
        ],
    ]
);
new \Kirki\Field\Text(
    [
        'settings' => 'top_category_section_title',
        'label'    => esc_html__( 'Top Category', 'brighter-blog' ),
        'default'     => 'Top Category',
        'section'  => 'top_category_options',
        'active_callback' => [
            [
                'setting'  => 'top_category_enable',
                'operator' => '==',
                'value'    => true,
            ],
        ],
        'partial_refresh'    => [
			'top_category_title_refresh' => [
				'selector'        => 'h2.top-category-title.section-title',
				'render_callback' => 'brighter_blog_top_category_customizer_quick_edit',
			],
		],
    ]
);
Kirki::add_field('brighter_blog_config', [
    'type'        => 'select',
    'settings'    => 'top_selected_categories',
    'label'       => esc_html__('Top Categories', 'brighter-blog'),
    'description' => esc_html__('Select categories to display. If no categories are selected, the latest categories will be shown.', 'brighter-blog'),
    'section'     => 'top_category_options', // Replace with your desired section
    'multiple'    => 10, // Allow multiple selection
    'choices'     => get_categories(['fields' => 'id=>name']), // Get all categories
    'default'     => [], // Default empty array
    'active_callback' => [
            [
                'setting'  => 'top_category_enable',
                'operator' => '==',
                'value'    => true,
            ],
        ],
]);

Kirki::add_field( 'theme_config', [
    'type'        => 'custom',
    'settings'    => 'top_categories_pro_feature_upgrade',
    'section'     => 'top_category_options',
    'default'     => '
        <div style="text-align: center; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
            <h3 style="margin-bottom: 10px;">' . esc_html__( 'Upgrade to Pro!', 'brighter-blog' ) . '</h3>
            <p style="margin-bottom: 15px;">' . esc_html__( 'Unlock exclusive features and customization options by upgrading to the Pro version.', 'brighter-blog' ) . '</p>
            <img src="' . esc_url( get_template_directory_uri() . '/assets/images/free/hero.png' ) . '" alt="' . esc_attr__( 'Pro Feature', 'brighter-blog' ) . '" style="max-width: 100%; border-radius: 10px; margin-bottom: 15px;" />
            <a href="'.esc_url(brighter_blog_purchase_link()).'" target="_blank" style="display: inline-block; padding: 10px 20px; background-color: #6c63ff; color: #fff; text-decoration: none; border-radius: 5px; font-weight: bold;">' . esc_html__( 'Upgrade Now', 'brighter-blog' ) . '</a>
        </div>
    ',
    'active_callback' => [
        [
            'setting'  => 'top_category_enable',
            'operator' => '==',
            'value'    => true,
        ],
    ],
] );
