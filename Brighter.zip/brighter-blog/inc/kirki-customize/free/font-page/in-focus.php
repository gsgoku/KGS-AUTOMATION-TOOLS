<?php
/**
* Start In Focus
*/

kirki::add_section( 'in_focus_options', array(
'title'    => esc_html__( 'In Focus', 'brighter-blog' ),
'panel'    => 'font-page-settings',
) );

//enable disable In Focus
new \Kirki\Field\Checkbox_Switch(
    [
        'label'       => esc_html__( 'Enable In Focus', 'brighter-blog' ),
        'section'     => 'in_focus_options',
        'settings' => 'enable_in_focus_section',
        'default'     => 'on',
        'choices'     => [
            'on'  => esc_html__( 'Enable', 'brighter-blog' ),
            'off' => esc_html__( 'Disable', 'brighter-blog' ),
        ],
    ]
);


new \Kirki\Field\Text(
    [
        'settings' => 'in_focus_section_title',
        'label'    => esc_html__( 'In Focus', 'brighter-blog' ),
        'default'     => 'In Focus',
        'section'  => 'in_focus_options',
        'active_callback' => [
            [
                'setting'  => 'enable_in_focus_section',
                'operator' => '==',
                'value'    => true,
            ],
        ],
        'partial_refresh'    => [
			'in_focus_title_refresh' => [
				'selector'        => 'h2.in-focus-title.section-title',
				'render_callback' => 'brighter_blog_in_focus_customizer_quick_edit',
			],
		],
    ]
);




// Toggle Field: Choose between Category or Latest Post
new \Kirki\Field\Radio(
    [
        'settings'    => 'in_focus_choose_cat_or_latest',
        'label'       => esc_html__( 'Select Content Type', 'brighter-blog' ),
        'section'     => 'in_focus_options',
        'default'     => 'latest',

        'choices'     => [
            'latest'     => esc_html__( 'Latest Post', 'brighter-blog' ),
        ],
        'active_callback' => [
            [
                'setting'  => 'enable_in_focus_section',
                'operator' => '==',
                'value'    => true,
            ],
        ],
    ]
);
Kirki::add_field( 'theme_config', [
    'type'        => 'custom',
    'settings'    => 'in_focus_pro_feature_upgrade',
    'section'     => 'in_focus_options',
    'default'     => '
        <div style="text-align: center; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
            <h3 style="margin-bottom: 10px;">' . esc_html__( 'Upgrade to Pro!', 'brighter-blog' ) . '</h3>
            <p style="margin-bottom: 15px;">' . esc_html__( 'Unlock exclusive features and customization options by upgrading to the Pro version.', 'brighter-blog' ) . '</p>
            <img src="' . esc_url( get_template_directory_uri() . '/assets/images/free/in-focus.png' ) . '" alt="' . esc_attr__( 'Pro Feature', 'brighter-blog' ) . '" style="max-width: 100%; border-radius: 10px; margin-bottom: 15px;" />
            <a href="'.esc_url(brighter_blog_purchase_link()).'" target="_blank" style="display: inline-block; padding: 10px 20px; background-color: #6c63ff; color: #fff; text-decoration: none; border-radius: 5px; font-weight: bold;">' . esc_html__( 'Upgrade Now', 'brighter-blog' ) . '</a>
        </div>
    ',
    'active_callback' => [
        [
            'setting'  => 'enable_in_focus_section',
            'operator' => '==',
            'value'    => true,
        ],
    ],
] );

// side bar enable disable code
new \Kirki\Field\Checkbox_Switch(
    [
        'label'       => esc_html__( 'Enable Disable In Focus SideBar', 'brighter-blog' ),
        'section'     => 'in_focus_options',
        'settings' => 'infocus_side_bar_enable_disable',
        'default'     => 'on',
        'choices'     => [
            'on'  => esc_html__( 'Enable', 'brighter-blog' ),
            'off' => esc_html__( 'Disable', 'brighter-blog' ),
        ],
        'active_callback' => [
        [
            'setting'  => 'enable_in_focus_section',
            'operator' => '==',
            'value'    => true,
        ],
    ],
    ]
);