<?php
kirki::add_section( 'middle_ads_options', array(
    'title'    => esc_html__( 'Middle Ads ', 'brighter-blog' ),
    'panel'    => 'font-page-settings',
    ) );

//Hide show ads
new \Kirki\Field\Checkbox_Switch(
	[
		'settings'    => 'middle_ads_enable',
		'label'       => esc_html__( 'Enable Middle Ads', 'brighter-blog' ),
		'section'     => 'middle_ads_options',
		'default'     => 'on',
		'choices'     => [
			'on'  => esc_html__( 'Enable', 'brighter-blog' ),
			'off' => esc_html__( 'Disable', 'brighter-blog' ),
		],
	]
);


new \Kirki\Field\Image(
	[
		'settings'    => 'middle_ads_image',
		'label'       => esc_html__( 'Middle Ads Image', 'brighter-blog' ),
		'description' => esc_html__( 'Ad images recommended size (615 x 69 Px)', 'brighter-blog' ),
		'section'     => 'middle_ads_options',
		'active_callback' => [
			[
				'setting'  => 'middle_ads_enable',
				'operator' => '==',
				'value'    => true,
			]
		],
		'default'     => get_template_directory_uri() . '/assets/images/ads/ads-3.png',
	]
);


new \Kirki\Field\URL(
	[
		'settings' => 'middle_ads_image_url',
		'label'    => esc_html__( 'Middle Ads url', 'brighter-blog' ),
		'section'  => 'middle_ads_options',
		'default'  => 'https://www.mycodecare.com/brighter',
		'active_callback' => [
			[
				'setting'  => 'middle_ads_enable',
				'operator' => '==',
				'value'    => true,
			],

		],
		'partial_refresh'    => [
			'middle_ads_title_refresh' => [
				'selector'        => '.middle-ads-banner-edit',
				'render_callback' => 'brighter_blog_customizer_middle_ads_quick_edit',
			],
		],
		
	]
);