<?php 
/**
 * Trending Video Setting
 */
Kirki::add_section( 'trending_video_section', array(
	'title'    => esc_html__( 'Video Post Section', 'brighter-blog' ),
	'panel'    => 'font-page-settings',
) );

Kirki::add_field( 'theme_config', [
	'type'        => 'switch',
	'settings'    => 'enable_video_section',
	'label'       => esc_html__( 'Enable Video Section', 'brighter-blog' ),
	'section'     => 'trending_video_section',
	'default'     => false, 
	'choices'     => [
		true  => esc_html__( 'Enable', 'brighter-blog' ), 
		false => esc_html__( 'Disable', 'brighter-blog' ), 
	],
] );


new \Kirki\Field\Text(
	[
		'settings' => 'video_section_title',
		'label'    => esc_html__( 'Video Section Title', 'brighter-blog' ),
		'section'  => 'trending_video_section',
		'default'  => esc_html__( 'Video Post', 'brighter-blog' ),
        'active_callback' => [
			[
				'setting'  => 'enable_video_section',
				'operator' => '===',
				'value'    => true,
			],
			
		],
		'partial_refresh'    => [
			'video_section_title_refresh' => [
				'selector'        => '.video-edit',
				'render_callback' => 'brighter_blog_customizer_quickedit',
			],
		],
		
	]
);


// Select Category 
new \Kirki\Field\Select(
    [
        'settings'    => 'select_video_category',
        'label'       => esc_html__( 'Select Category ', 'brighter-blog' ),
        'section'     => 'trending_video_section',
        'default'     => array(1),
        'placeholder' => esc_html__( 'Choose An Category', 'brighter-blog' ),
        'multiple'    => 2,
        'choices'     => Kirki\Util\Helper::get_terms(array('taxonomy' => 'category')),
        'active_callback' => [
            [
                'setting'  => 'enable_video_section',
                'operator' => '==',
                'value'    => true,
            ],
           
        ]
    ]
);
Kirki::add_field( 'theme_config', [
    'type'        => 'custom',
    'settings'    => 'trending_video_pro_feature_upgrade',
    'section'     => 'trending_video_section',
    'default'     => '
        <div style="text-align: center; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
            <h3 style="margin-bottom: 10px;">' . esc_html__( 'Upgrade to Pro!', 'brighter-blog' ) . '</h3>
            <p style="margin-bottom: 15px;">' . esc_html__( 'Unlock exclusive features and customization options by upgrading to the Pro version.', 'brighter-blog' ) . '</p>
            <img src="' . esc_url( get_template_directory_uri() . '/assets/images/free/video.png' ) . '" alt="' . esc_attr__( 'Pro Feature', 'brighter-blog' ) . '" style="max-width: 100%; border-radius: 10px; margin-bottom: 15px;" />
            <a href="'.esc_url(brighter_blog_purchase_link()).'" target="_blank" style="display: inline-block; padding: 10px 20px; background-color: #6c63ff; color: #fff; text-decoration: none; border-radius: 5px; font-weight: bold;">' . esc_html__( 'Upgrade Now', 'brighter-blog' ) . '</a>
        </div>
    ',
    'active_callback' => [
        [
            'setting'  => 'enable_video_section',
            'operator' => '==',
            'value'    => true,
        ],
    ],
] );



