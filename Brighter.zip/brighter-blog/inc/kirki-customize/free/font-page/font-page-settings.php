<?php
Kirki::add_panel( 'font-page-settings', array(
    'title'    => esc_html__( 'Font Page Setting', 'brighter-blog' ),
    'priority' => 1
) );


