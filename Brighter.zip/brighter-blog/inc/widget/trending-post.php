<?php
// Creating the widget
class Brighter_Blog_Trending_Post extends WP_Widget
{
    function __construct()
    {
        parent::__construct(
            // Base ID of your widget
            'brighter_blog_trending_post',

            // Widget name that will appear in UI
            __('Brighter-blog: Trending Post', 'brighter-blog'),

            // Widget description
            array('description' => __('This widget is for trending post bar.', 'brighter-blog'),)
        );
    }

    // Creating widget front-end
    public function widget($args, $instance)
    {
        $title = apply_filters('widget_title', $instance['title']);

        // Before and after widget arguments are defined by themes
        echo wp_kses_post($args['before_widget']);
        if (!empty($title)) {
            echo wp_kses_post($args['before_title']) . esc_html($title) . wp_kses_post($args['after_title']);
        }
        ?>

        <div class="widget widget-trending-post">
            <div class="trending-post-wrap">

                <?php
                $brighter_blog_trending_args = array(
                    'post_type' => 'post',
                    'post_status' => 'publish',
                    'posts_per_page' => 2,
                    'orderby'        => 'comment_count',
                    'order'          => 'DESC',
                    'ignore_sticky_posts' => 1,
                );

                $brighter_blog_trending_query = new WP_Query($brighter_blog_trending_args);

                if ($brighter_blog_trending_query->have_posts()) {
                    while ($brighter_blog_trending_query->have_posts()) {
                        $brighter_blog_trending_query->the_post();
                        $brighter_blog_trending_post_img = get_the_post_thumbnail_url() ? get_the_post_thumbnail_url() : get_template_directory_uri() . '/assets/images/no-image.jpg';

                        // Get the post thumbnail ID
                        $thumbnail_id = get_post_thumbnail_id(get_the_ID());
                        if (get_the_post_thumbnail_url()) {
                            $alt_text = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
                        } else {
                            $alt_text = 'No Image';
                        }
                        ?>
                        <div class="trending-post">
                            <div class="media-img">
                                <a href="<?php echo esc_url(get_the_permalink()); ?>">
                                    <img src="<?php echo esc_url($brighter_blog_trending_post_img); ?>" alt="<?php echo esc_attr($alt_text); ?>">
                                </a>
                            </div>
                            <div class="media-body">
                                <h4 class="post-title">
                                    <a class="text-inherit" href="<?php echo esc_url(get_the_permalink()); ?>">
                                        <?php echo esc_html(wp_trim_words(get_the_title(), 5)); ?>
                                    </a>
                                </h4>
                                <div class="trending-post-meta">
                                    <a href="<?php echo esc_url(get_permalink()); ?>">
                                        <i class="far fa-calendar-check"></i> <?php echo esc_html(get_the_date()); ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }

                // Restore original post data
                wp_reset_postdata();
                ?>
            </div>
        </div>

        <?php
        echo wp_kses_post($args['after_widget']);
    }

    // Widget Backend
    public function form($instance)
    {
        if (isset($instance['title'])) {
            $title = $instance['title'];
        } else {
            $title = __('Trending Post', 'brighter-blog');
        }
        // Widget admin form
        ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'brighter-blog'); ?></label>
            <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
                   name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text"
                   value="<?php echo esc_attr($title); ?>"/>
        </p>
        <?php
    }

    // Updating widget replacing old instances with new
    public function update($new_instance, $old_instance)
    {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? sanitize_text_field($new_instance['title']) : '';

        return $instance;
    }
} // Class Brighter-Blog_Trending_Post ends here
?>