<?php
class Brighter_Blog_Category_Posts_Widget extends WP_Widget {

public function __construct() {
    parent::__construct(
        'brighter_blog_category_posts_widget', // Base ID
        __('Brighter Blog Category Posts', 'brighter-blog'), // Name
        array('description' => __('Display posts from a selected category.', 'brighter-blog'))
    );
}

// Output the widget form in the admin dashboard
public function form($instance) {
    $selected_category = !empty($instance['selected_category']) ? $instance['selected_category'] : '';
    $categories = get_categories(array('hide_empty' => false));
    ?>
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('selected_category')); ?>">
            <?php esc_html_e('Select Category:', 'brighter-blog'); ?>
        </label>
        <select id="<?php echo esc_attr($this->get_field_id('selected_category')); ?>" name="<?php echo esc_attr($this->get_field_name('selected_category')); ?>" class="widefat">
            <?php foreach ($categories as $category): ?>
                <option value="<?php echo esc_attr($category->term_id); ?>" <?php selected($selected_category, $category->term_id); ?>>
                    <?php echo esc_html($category->name); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </p>
    <?php
}

// Save widget options
public function update($new_instance, $old_instance) {
    $instance = array();
    $instance['selected_category'] = (!empty($new_instance['selected_category'])) ? sanitize_text_field($new_instance['selected_category']) : '';
    return $instance;
}

// Output the widget content on the front-end
public function widget($args, $instance) {
    $selected_category = !empty($instance['selected_category']) ? $instance['selected_category'] : '';

    if (!$selected_category || !get_category($selected_category)) {
        // Get a random category if the selected one is invalid
        $random_category = get_categories(array(
            'orderby' => 'rand',
            'number'  => 1,
        ));
        
        if (!empty($random_category)) {
            $selected_category = $random_category[0]->term_id;
        } else {
            return; // No categories found, exit
        }
    }

    // Get category details
    $category = get_category($selected_category);
    $category_name = $category ? $category->name : '';

    if (empty($category_name)) {
        return;
    }

    echo $args['before_widget'];
    echo $args['before_title'] . esc_html($category_name) . $args['after_title'];

    // Fetch posts from the selected category
    $query_args = array(
        'cat'                 => $selected_category,
        'posts_per_page'      => 5,
        'ignore_sticky_posts' => 1,
    );

    $query = new WP_Query($query_args);

    if ($query->have_posts()): ?>
        <div class="selected-category-posts-widget">
            <?php while ($query->have_posts()): $query->the_post(); ?>
                <?php
                    $post_img = (has_post_thumbnail()) ? get_the_post_thumbnail_url(get_the_ID(), 'thumbnail') : get_template_directory_uri() . '/assets/images/no-image.jpg';
                ?>
                <div class="widget-category-post row gx-20 gy-20 mb-2">
                    <div class="widget-post-img col-3">
                        <img src="<?php echo esc_url($post_img ); ?>" alt="">
                    </div>
                    <div class="widget-post-details col-9">
                        <a class="widget-post-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        <p class="widget-post-description">
                            <?php
                                $excerpt = get_the_excerpt();
                                $excerpt_words = explode(' ', $excerpt, 8);
                                if (count($excerpt_words) > 5) {
                                array_pop($excerpt_words);
                                    $excerpt = implode(' ', $excerpt_words) . '...';
                                }
                                echo esc_html($excerpt);
                            ?>
                        </p>
                    </div>
                    
                </div>
            <?php endwhile; ?>
    </div>
    <?php endif;
    wp_reset_postdata();

    echo $args['after_widget'];
}
}

