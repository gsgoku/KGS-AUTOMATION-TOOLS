<?php

require_once BRIGHTER_BLOG_INC_DIR . 'widget/recent-post-trending-post.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

// social media widget register 
require_once BRIGHTER_BLOG_INC_DIR . 'widget/social-follow.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

// social follow widget register 
require_once BRIGHTER_BLOG_INC_DIR . 'widget/social-media-widget.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

// Advertising widget register 
require_once BRIGHTER_BLOG_INC_DIR . 'widget/advertising-widget.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
// recent post widget register 
require_once BRIGHTER_BLOG_INC_DIR . 'widget/recent-post.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

// recent post widget register 
require_once BRIGHTER_BLOG_INC_DIR . 'widget/trending-post.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound


// recent post widget register 
require_once BRIGHTER_BLOG_INC_DIR . 'widget/category-post-widget.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound


// Register and load the widget
function brighter_blog_recent_trending_post_load_widget()
{   
    // Register Tranding Post the widget
    register_widget('brighter_blog_recent_trending_post');
   
    // Register social media widget

    register_widget('brighter_blog_social_media_widget'); 

     // Register social media follow widget

    register_widget('brighter_blog_social_follow_widget');

    // Register Advertising widget

    register_widget('brighter_blog_advertising_widget');

    // Register Recent Post widget

    register_widget('brighter_blog_recent_post');

    // Register Trending Post widget

    register_widget('brighter_blog_trending_post');

    // Register the Category Post widget

    register_widget('Brighter_Blog_Category_Posts_Widget');
 
    


    
}

add_action('widgets_init', 'brighter_blog_recent_trending_post_load_widget');

