<?php
// Breadcrumb function for WordPress
function brighter_blog_breadcrumb() {
	// Settings
	$separator  = '>';
	$home_title = 'Home';

	// Get the query & post information
	global $post, $wp_query;

	// Do not display on the homepage
	if ( ! is_front_page() ) {
		echo '<div class="breadcrumb-space-bottom">';
		echo '<ul class="breadcrumb">';
		echo '<li class="breadcrumb-item"><a href="' . get_home_url() . '">' . esc_html( $home_title ) . '</a></li>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<li class="separator">' . esc_html( $separator ) . '</li>';

		if ( is_archive() ) {
			if ( ! is_tax() && ! is_category() && ! is_tag() ) {
				echo '<li class="breadcrumb-item">' . post_type_archive_title( '', false ) . '</li>';
			} else {
				$post_type = get_post_type();
				if ( $post_type != 'post' ) {
					$post_type_object  = get_post_type_object( $post_type );
					$post_type_archive = get_post_type_archive_link( $post_type );

					echo '<li class="breadcrumb-item"><a href="' . esc_html( $post_type_archive ) . '">' . esc_html( $post_type_object->labels->name ) . '</a></li>';
					echo '<li class="separator">' . esc_html( $separator ) . '</li>';
				}

				echo '<li class="breadcrumb-item">' . single_term_title( '', false ) . '</li>';
			}
		} elseif ( is_single() ) {
			$post_type = get_post_type();
			if ( $post_type != 'post' ) {
				$post_type_object  = get_post_type_object( $post_type );
				$post_type_archive = get_post_type_archive_link( $post_type );

				echo '<li class="breadcrumb-item 343434"><a href="' . esc_html( $post_type_archive . '">' . esc_html( $post_type_object->labels->name ) ) . '</a></li>';
				echo '<li class="separator">' . esc_html( $separator ) . '</li>';
			}
			$category = get_the_category();
			if ( ! empty( $category ) ) {
				$last_category = end( $category );
				$cat_parents   = rtrim( get_category_parents( $last_category->term_id, true, ',' ), ',' );
				$cat_parents   = explode( ',', $cat_parents );

				foreach ( $cat_parents as $parent ) {
					echo '<li class="breadcrumb-item t55t334t">' .  $parent . '</li>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<li class="separator">' . esc_html( $separator ) . '</li>';
				}
			}

			echo '<li class="breadcrumb-item g5tynh">' . get_the_title() . '</li>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped


		} elseif ( is_page() ) {
			if ( $post->post_parent ) {
				$ancestors = get_post_ancestors( $post->ID );
				$ancestors = array_reverse( $ancestors );

				foreach ( $ancestors as $ancestor ) {
					echo '<li class="breadcrumb-item 5t5t5t5"><a href="' . get_permalink( $ancestor ) . '">' . get_the_title( $ancestor ) . '</a></li>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					echo '<li class="separator">' . esc_html( $separator ) . '</li>';
				}
			}

			echo '<li class="breadcrumb-item fff">' . get_the_title() . '</li>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} elseif ( is_category() ) {
			echo '<li class="breadcrumb-item">' . single_cat_title( '', false ) . '</li>';
		} elseif ( is_tag() ) {
			echo '<li class="breadcrumb-item ggg">' . single_tag_title( '', false ) . '</li>';
		} elseif ( is_day() ) {
			echo '<li class="breadcrumb-item ttt"><a href="' . get_year_link( get_the_time( 'Y' ) ) . '">' . get_the_time( 'Y' ) . '</a></li>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '<li class="separator">' . esc_html( $separator ) . '</li>';
			echo '<li class="breadcrumb-item uuuu"><a href="' . get_month_link( get_the_time( 'Y' ), get_the_time( 'm' ) ) . '">' . get_the_time( 'F' ) . '</a></li>';/// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '<li class="separator">' . esc_html( $separator ) . '</li>';
			echo '<li class="breadcrumb-item 555">' . get_the_time( 'jS' ) . '</li>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} elseif ( is_month() ) {
			echo '<li class="breadcrumb-item 7u7u"><a href="' . get_year_link( get_the_time( 'Y' ) ) . '">' . get_the_time( 'Y' ) . '</a></li>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '<li class="separator">' . esc_html( $separator ) . '</li>';
			echo '<li class="breadcrumb-item 8ii87">' . get_the_time( 'F' ) . '</li>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} elseif ( is_year() ) {
			echo '<li class="breadcrumb-item h6767">' . get_the_time( 'Y' ) . '</li>';// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} elseif ( is_author() ) {
			global $author;
			$userdata = get_userdata( $author );
			echo '<li class="breadcrumb-item">Author: ' . esc_html( $userdata->display_name ) . '</li>';
		} elseif ( is_search() ) {
			echo '<li class="breadcrumb-item">Search results for: ' . get_search_query() . '</li>';
		} elseif ( is_404() ) {
			echo '<li class="breadcrumb-item">Error 404</li>';
		}

		echo '</ul>';
		echo '</div>';
	}
}

// Add breadcrumb action
add_action( 'brighter_blog_breadcrumb', 'brighter_blog_breadcrumb' );

// Post pagination function
function brighter_blog_post_pagination() {
	the_posts_pagination( array(
		'screen_reader_text' => '',
		'prev_text'          => '<i class="fa fa-angle-double-left"></i>',
		'next_text'          => '<i class="fas fa-angle-double-right"></i>',
		'type'               => 'list',
		'mid_size'           => 1,
	) );
}


//Dark logo
function brighter_blog_dark_logo_customize_register($wp_customize) {
	// Add a setting for the dark mode logo
	$wp_customize->add_setting('dark_mode_logo', array(
		'default'   => '',
		'transport' => 'refresh',
		'sanitize_callback' => 'brighter_blog_sanitize_image_url',
	));

	// Add the control for the dark mode logo
	$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'dark_mode_logo', array(
		'label'      => __('Dark Mode Logo', 'brighter-blog'),
		'section'    => 'title_tagline',
		'settings'   => 'dark_mode_logo',
	)));
}
add_action('customize_register', 'brighter_blog_dark_logo_customize_register');

// Sanitization callback function for the dark mode logo URL
function brighter_blog_sanitize_image_url($url) {
	return esc_url_raw($url);
}


//Add custom menu
function brighter_blog_menu_page() {
    add_menu_page(
        'Brighter Blog', // Page title
        'Brighter Blog Theme',       // Menu title
        'manage_options',    // Capability
        'brighter-blog',  // Menu slug
        'brighter_blog_menu_page_content', // Function to display page content
        'dashicons-format-aside', // Icon URL (dashicons for WP icons)
        6                    // Position
    );
}
add_action( 'admin_menu', 'brighter_blog_menu_page' );

function brighter_blog_menu_page_content() {
    echo '<h1>Welcome to Brighter Blog Theme.</h1>';
}

function brighter_blog_ocdi_import_files() {
    $demo_base_url = 'https://link.mycodecare.com/demo/brighter-blog/';

	$default_demo_url = 'https://brighter-blog.mycodecare.com';
	$food_demo_url = 'https://brighter-blog.mycodecare.com/food';
	$fashion_demo_url = 'https://brighter-blog.mycodecare.com/fashion';
	$travel_demo_url = 'https://brighter-blog.mycodecare.com/travel';
	$technology_demo_url = 'https://brighter-blog.mycodecare.com/tech';

    return [
        [
            'import_file_name'           => 'Default Demo',
            'categories'                 => ['Default'],
            'import_file_url'            => $demo_base_url . 'default/default.xml',
            'import_widget_file_url'     => $demo_base_url . 'default/default.wie',
            'import_customizer_file_url' => $demo_base_url . 'default/default.dat',
            'import_preview_image_url'   => $demo_base_url . 'default/default.jpg',
            'preview_url'                => $default_demo_url,
        ],
		[
            'import_file_name'           => 'Fashion Demo',
            'categories'                 => ['Fashion'],
            'import_file_url'            => $demo_base_url . 'fashion/fashion.xml',
            'import_widget_file_url'     => $demo_base_url . 'fashion/fashion.wie',
            'import_customizer_file_url' => $demo_base_url . 'fashion/fashion.dat',
            'import_preview_image_url'   => $demo_base_url . 'fashion/fashion.jpg',
            'preview_url'                => $fashion_demo_url,
        ],
        [
            'import_file_name'           => 'Food Demo',
            'categories'                 => ['Food'],
            'import_file_url'            => $demo_base_url . 'food/food.xml',
            'import_widget_file_url'     => $demo_base_url . 'food/food.wie',
            'import_customizer_file_url' => $demo_base_url . 'food/food.dat',
            'import_preview_image_url'   => $demo_base_url . 'food/food.jpg',
            'preview_url'                => $food_demo_url,
        ],
        [
            'import_file_name'           => 'Technology Demo',
            'categories'                 => ['Technology'],
            'import_file_url'            => $demo_base_url . 'technology/technology.xml',
            'import_widget_file_url'     => $demo_base_url . 'technology/technology.wie',
            'import_customizer_file_url' => $demo_base_url . 'technology/technology.dat',
            'import_preview_image_url'   => $demo_base_url . 'technology/technology.jpg',
            'preview_url'                => $technology_demo_url,
        ],
        [
            'import_file_name'           => 'Travel Demo',
            'categories'                 => ['Travel'],
            'import_file_url'            => $demo_base_url . 'travel/travel.xml',
            'import_widget_file_url'     => $demo_base_url . 'travel/travel.wie',
            'import_customizer_file_url' => $demo_base_url . 'travel/travel.dat',
            'import_preview_image_url'   => $demo_base_url . 'travel/travel.jpg',
            'preview_url'                => $travel_demo_url,
        ]
    ];
}
add_filter( 'ocdi/import_files', 'brighter_blog_ocdi_import_files' );
function ocdi_after_import_setup() {
    // Assign menus to their locations.
    $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
    $footer_menu = get_term_by( 'name', 'Footer Menu', 'nav_menu' );
    set_theme_mod( 'nav_menu_locations', array(
            'primary' => $main_menu->term_id, // replace 'main-menu' here with the menu location identifier from register_nav_menu() function
            'footer' => $footer_menu->term_id, // replace 'main-menu' here with the menu location identifier from register_nav_menu() function
        )
    );
}
add_action( 'ocdi/after_import', 'ocdi_after_import_setup' );

