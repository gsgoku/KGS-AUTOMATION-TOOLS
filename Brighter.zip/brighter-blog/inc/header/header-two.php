<?php if (get_theme_mod('theme_header_enable', true)) : ?>
    <header id="masthead" class="site-header nav-header header-layout2">
        <?php if (get_theme_mod('enable_top_header', true)) : ?>
            <div class="header-top d-lg-block d-none">
                <div class="container">
                    <div class="row justify-content-center justify-content-lg-between align-items-center gy-2">
                        <?php
                        $brighter_blog_enable_top_top_left = get_theme_mod('header_two_enable_top_header_left_side', 'on');
                        if ($brighter_blog_enable_top_top_left == 'on') {
                            ?>
                            <div class="col-xl-3 col-lg-3">
                                <?php if(get_theme_mod('header_two_date_time_section', true)) : ?>
                                    <span class="header-datetime"><i class="fa-regular fa-calendar-days"></i> <span class="ms-2"><?php echo esc_html(current_time('l - F j, Y')); ?></span></span>
                                <?php
                                    endif;
                                ?>
                            </div>
                            <?php
                        }
                        ?>
                        
                        <?php
                        $brighter_blog_enable_header_top_middle = get_theme_mod('header_two_enable_header_top_middle_side', 'on');
                        if ($brighter_blog_enable_header_top_middle == 'on') {
                            ?>
                            <div class="col-5 d-none d-lg-block">
                                <?php if (get_theme_mod('sticky_header_enable', true)) : ?>
                                    <div class="header-top-logo site-branding">
                                        <?php
                                        if (has_custom_logo()) {
                                            // Display custom logo with specified size
                                            $custom_logo_id = get_theme_mod('custom_logo');
                                            $custom_dark_logo_url = get_theme_mod('dark_mode_logo');
                                            $logo = wp_get_attachment_image_src($custom_logo_id, 'full');

                                            if ($custom_dark_logo_url) {
                                                $darkLogoUrl = $custom_dark_logo_url;
                                            } else {
                                                $darkLogoUrl = $logo[0];
                                            }

                                            if ($logo) {
                                                $logo_width = $logo[1];
                                                $logo_height = $logo[2];

                                                // Check if the logo dimensions are both 80px
                                                if ($logo_width <= 80 && $logo_height <= 80) {
                                                    $width = '80px';
                                                    $height = '80px';
                                                } else {
                                                    // Default to 185x60 if not both 80px
                                                    $width = '185px';
                                                    $height = '60px';
                                                }
                                                ?>
                                                <a class="light-logo" href="<?php echo esc_url(home_url()) ?>">
                                                    <img src="<?php echo esc_url($logo[0]) ?>" alt="<?php bloginfo('name') ?>">
                                                </a>
                                                <a class="dark-logo" href="<?php echo esc_url(home_url()) ?>">
                                                    <img src="<?php echo esc_url($darkLogoUrl); ?>" alt="<?php bloginfo('name') ?>">
                                                </a>
                                                <?php
                                            }
                                        } else {
                                            if (is_front_page() && is_home()) {
                                                ?>
                                                <h2 class="site-title"><a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name') ?></a></h2>
                                                <?php
                                            } else {
                                                ?>
                                                <h2 class="site-title"><a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name') ?></a></h2>
                                                <?php
                                            }
                                        }

                                        $brighter_blog_description = get_bloginfo('description', 'display');
                                        if ($brighter_blog_description || is_customize_preview()) {
                                            echo '<p class="site-description">' . esc_html($brighter_blog_description) . '</p>';
                                        }
                                        ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php
                        }
                        ?>
                        <?php
                        $brighter_blog_enable_header_top_right = get_theme_mod('header_two_enable_header_top_right_side', 'on');
                        if ($brighter_blog_enable_header_top_right == 'on') {
                            ?>
                            <div class="col-4 d-none d-lg-block">
                                 <?php
                                $brighter_blog_icon_settings = get_theme_mod('header_two_header_social_enable', 'on');
                                if ($brighter_blog_icon_settings == 'on') {
                                    $brighter_blog_social_defaults = [
                                        [
                                            'social_icon' => 'fab fa-facebook-f',
                                            'link_url' => '#',
                                        ],
                                        [
                                            'social_icon' => 'fa-brands fa-x-twitter',
                                            'link_url' => '#',
                                        ],
                                        [
                                            'social_icon' => 'fa-brands fa-linkedin-in',
                                            'link_url' => '#',
                                        ],
                                        [
                                            'social_icon' => 'fa-brands fa-instagram',
                                            'link_url' => '#',
                                        ],
                                    ];

                                    // Theme_mod settings to check.
                                    $brighter_blog_icon_settings = get_theme_mod('header_two_social_media_icon', $brighter_blog_social_defaults);
                                    ?>
                                        <div class="header-links">
                                            <ul>
                                                <li class="d-md-block d-none">
                                                    <div class="social-btn style3">
                                                        <?php foreach ($brighter_blog_icon_settings as $brighter_blog_icon_setting) : ?>
                                                            <a href="<?php echo esc_url($brighter_blog_icon_setting['link_url']); ?>" tabindex="0">
                                                                <i class="<?php echo esc_attr($brighter_blog_icon_setting['social_icon']); ?>"></i>
                                                            </a>
                                                        <?php endforeach; ?>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    <?php
                                }
                                ?>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- ===================== Middle Header Starts ===================== -->
        <?php if (get_theme_mod('header_middle_enable', true)) : ?>
            <div class="header-middle">
                <div class="container">
                    <div class="row align-items-center border-b">
                        <div class="col-12 d-lg-block">
                            <?php if (get_theme_mod('sticky_header_enable', true)) : ?>
                                <div class="sticky-wrapper">
                            <?php endif; ?>
                                    <?php
                                    $sticky_header_enable = get_theme_mod('sticky_header_enable', 'on');
                                    $sticky_class = $sticky_header_enable ? 'sticky' : '';
                                    $col_class = $sticky_header_enable ? 'col-xl-3' : 'col-xl-3';
                                    $col2_class = $sticky_header_enable ? 'col-xl-7' : 'col-xl-7';
                                    $col3_class = $sticky_header_enable ? 'col-xl-2' : 'col-xl-2';
                                    ?>
                                    <!-- Main Menu Area -->
                                    <div class="menu-area header-middle-middle">
                                        <div class="container">
                                            <div class="row align-items-center justify-content-between">
                                                <div class="col col-sm-6 col-md-4 col-lg-4 <?php echo esc_attr($col_class); ?> header-logo">
                                                    <div class="theme-logos">
                                                        <?php
                                                        if (has_custom_logo()) {
                                                            $custom_logo_id = get_theme_mod('custom_logo');
                                                            $custom_dark_logo_url = get_theme_mod('dark_mode_logo');
                                                            $logo = wp_get_attachment_image_src($custom_logo_id, 'full');

                                                            $darkLogoUrl = $custom_dark_logo_url ? $custom_dark_logo_url : $logo[0];

                                                            if ($logo) {
                                                                $logo_width = $logo[1];
                                                                $logo_height = $logo[2];

                                                                $width = ($logo_width <= 80 && $logo_height <= 80) ? '80px' : '185px';
                                                                $height = ($logo_width <= 80 && $logo_height <= 80) ? '80px' : '60px';
                                                                ?>
                                                                <a class="light-logo" href="<?php echo esc_url(home_url()); ?>">
                                                                    <img src="<?php echo esc_url($logo[0]); ?>" alt="<?php bloginfo('name'); ?>">
                                                                </a>
                                                                <a class="dark-logo" href="<?php echo esc_url(home_url()); ?>">
                                                                    <img src="<?php echo esc_url($darkLogoUrl); ?>" alt="<?php bloginfo('name'); ?>">
                                                                </a>
                                                                <?php
                                                            }
                                                        } else {
                                                            if (is_front_page() && is_home()) {
                                                                ?>
                                                                <h2 class="site-title">
                                                                    <a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name') ?></a>
                                                                </h2>
                                                                <?php
                                                            } else {
                                                                ?>
                                                                <h2 class="site-title">
                                                                    <a href="<?php echo esc_url(home_url('/')); ?>" rel="home"><?php bloginfo('name') ?></a>
                                                                </h2>
                                                                <?php
                                                            }
                                                        }

                                                        $brighter_blog_description = get_bloginfo('description', 'display');
                                                        if ($brighter_blog_description || is_customize_preview()) {
                                                            echo '<p class="site-description">' . esc_html($brighter_blog_description) . '</p>';
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                                <div class="col col-sm-6 col-md-2 col-lg-10 <?php echo esc_attr($col2_class); ?> mainmenu-dflex">
                                                    <nav class="main-menu d-none d-lg-inline-block">
                                                        <?php
                                                        wp_nav_menu(
                                                            array(
                                                                'container' => false,
                                                                'theme_location' => 'primary-menu',
                                                                'menu_id' => 'primary-menu',
                                                                'fallback_cb' => 'brighter_blog_primary_navigation_fallback',
                                                            )
                                                        );
                                                        ?>
                                                    </nav>
                                                    <div class="d-flex justify-content-sm-end justify-content-end">
                                                        <div class="navbar-right d-inline-flex d-lg-none">
                                                            <div class="theme-switcher">
                                                                <button>
                                                                    <span class="dark-mode-icon"> <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/moon.svg'); ?>" alt="Dark Mode"></span>
                                                                    <span class="light-mode-icon"> <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/sunshine.svg'); ?>" alt="Light Mode"></span>
                                                                </button>
                                                            </div>
                                                            <button type="button" class="menu-toggle icon-btn"><i class="fas fa-bars"></i></button>
                                                        </div>
                                                        <!--==============================
                                                            Mobile Menu
                                                        ============================== -->
                                                        <div class="mobile-menu-wrapper">
                                                            <div class="mobile-menu-area text-center">
                                                                <button class="menu-toggle"><i class="fas fa-times"></i></button>
                                                                <div class="mobile-logo">
                                                                    <?php
                                                                    if (has_custom_logo()) {
                                                                        $custom_logo_id = get_theme_mod('custom_logo');
                                                                        $custom_dark_logo_url = get_theme_mod('dark_mode_logo');
                                                                        $logo = wp_get_attachment_image_src($custom_logo_id, 'full');

                                                                        if ($custom_dark_logo_url) {
                                                                            $darkLogoUrl = $custom_dark_logo_url;
                                                                        } else {
                                                                            $darkLogoUrl = $logo[0];
                                                                        }

                                                                        if ($logo) {
                                                                            $logo_width = $logo[1];
                                                                            $logo_height = $logo[2];

                                                                            $width = ($logo_width <= 80 && $logo_height <= 80) ? '80px' : '185px';
                                                                            $height = ($logo_width <= 80 && $logo_height <= 80) ? '80px' : '60px';
                                                                            ?>
                                                                            <a class="light-logo remove-text-decoration" href="<?php echo esc_url(home_url()); ?>">
                                                                                <img class="mobile-menu-logo" src="<?php echo esc_url($logo[0]) ?>" alt="<?php bloginfo('name') ?>" style="width: <?php echo esc_attr($width) ?>; height: <?php esc_attr($height) ?>;">
                                                                            </a>
                                                                            <a class="dark-logo remove-text-decoration" href="<?php echo esc_url(home_url()); ?>">
                                                                                <img class="mobile-menu-logo" src="<?php echo esc_url($darkLogoUrl) ?>" alt="<?php bloginfo('name') ?>" style="width: <?php echo esc_attr($width) ?>; height: <?php esc_attr($height) ?>;">
                                                                            </a>
                                                                            <?php
                                                                        }
                                                                    } else {
                                                                        ?>
                                                                        <h2 class="site-title">
                                                                            <a class="remove-text-decoration" href="<?php echo esc_url(home_url('/')) ?>" rel="home">
                                                                                <?php bloginfo('name'); ?>
                                                                            </a>
                                                                        </h2>
                                                                        <?php
                                                                    }

                                                                    $brighter_blog_description = get_bloginfo('description', 'display');
                                                                    if ($brighter_blog_description || is_customize_preview()) {
                                                                        echo '<p class="site-description">' . esc_html($brighter_blog_description) . '</p>';
                                                                    }
                                                                    ?>
                                                                </div>
                                                                <div class="mobile-menu">
                                                                    <?php
                                                                    wp_nav_menu(
                                                                        array(
                                                                            'container' => false,
                                                                            'theme_location' => 'primary-menu',
                                                                            'menu_id' => 'primary-menu',
                                                                            'menu_class' => 'sf-menu',
                                                                            'fallback_cb' => 'brighter_blog_primary_navigation_fallback',
                                                                        )
                                                                    );
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- Mobile menu toggle ends -->
                                                    </div>
                                                </div>
                                                <div class="col col-sm-12 col-md-1 col-lg-2 <?php echo esc_attr($col3_class); ?> d-none d-lg-block">
                                                    <div class="header-button">
                                                        <!-- WooCommerce Cart and Account -->
                                                        <?php if (class_exists('WooCommerce')) : ?>
                                                            <a href="<?php echo esc_url(wc_get_cart_url()); ?>" class="nav-link position-relative cart-icon">
                                                                <i class="fa-solid fa-cart-shopping"></i>
                                                                
                                                                <span class="position-absolute translate-middle cart-badge rounded-pill">
                                                                    <?php echo esc_html(WC()->cart->get_cart_contents_count()); ?>
                                                                </span>
                                                            </a>
                                                        <?php endif; ?>
                                                        <?php
                                                        $brighter_blog_light_dark = get_theme_mod('enable_light_dark_section', 'on');
                                                        if ($brighter_blog_light_dark == 'on') {
                                                            ?>
                                                            <div class="theme-switcher">
                                                                <button>
                                                                    <span class="dark-mode-icon"> <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/moon.svg'); ?>" alt="Dark Mode"></span>
                                                                    <span class="light-mode-icon"> <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/sunshine.svg'); ?>" alt="Light Mode"></span>
                                                                </button>
                                                            </div>
                                                            <?php
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php if (get_theme_mod('sticky_header_enable', true)) : ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!--=================== Bottom Header Starts ========================== -->
        <?php if (get_theme_mod('header_bottom_enable', true)) : ?>
            <div class="header-bottom space-top">
                <div class="container">
                    <div class="row">
                        <?php if (get_theme_mod('header_ads_enable', true)) : ?>
                            <div class="col-12">
                                <div class="ad-banner-wrap">
                                    <?php
                                    $brighter_blog_top_ad_image = get_theme_mod('header_ads_image', get_template_directory_uri() . '/assets/images/ads/ads-1.jpg');
                                    $brighter_blog_top_ad_url = get_theme_mod('header_ads_image_url', '#');
                                    if ($brighter_blog_top_ad_image) {
                                        ?>
                                        <a class="header-ads-top" href="<?php echo esc_url_raw($brighter_blog_top_ad_url); ?>" target="_blank">
                                            <img class="ads-img" src="<?php echo esc_url($brighter_blog_top_ad_image); ?>" alt="Header Ads">
                                        </a>
                                        <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </header><!-- #masthead -->
<?php endif; ?>