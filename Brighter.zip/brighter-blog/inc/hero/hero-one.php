<?php
$brighter_blog_tag_color = array('blue', 'red', 'purple', 'dark-pink', 'pink','dark-red','dark-green','light-blue','pest','megenda','light-purple');
if (get_theme_mod('enable_hero_post', true)) : 
    // Fetch the selected category from the Customizer
    $hero_post_category = get_theme_mod('hero_post_category', '');
    $hero_post_order = get_theme_mod('hero_post_order', 'desc');
    $hero_post_orderby = get_theme_mod('hero_post_orderby', 'date');
    $hero_post_display_number = get_theme_mod('hero_post_display_number', '1');
    // Define query arguments
    $hero_post_query_args = [
        'post_type'      => 'post',
        'order'         => $hero_post_order,
        'orderby'         => $hero_post_orderby,
        'posts_per_page' => $hero_post_display_number, // Fetch one post
        'ignore_sticky_posts' => 1,
    ];

    if (!empty($hero_post_category)) {
        $hero_post_query_args['category_name'] = $hero_post_category; // Filter by selected category
    }

    $hero_post_query = new WP_Query($hero_post_query_args);

    if ($hero_post_query->have_posts()) {
        ?>
        <div class="overflow-hidden hero-post">
                <div class="row gx-20">
                    <?php
                    while ($hero_post_query->have_posts()) {
                        $hero_post_query->the_post();
                        $brighter_blog_post_id = get_the_ID();
                        $post_excerpt = get_the_excerpt();
                        $post_date = get_the_date('F j, Y');
                        $post_author_id = get_post_field('post_author');
                        $post_author_name = get_the_author_meta('display_name', $post_author_id);
                        $post_author_avatar = get_avatar_url($post_author_id);
                        $post_categories = get_the_category();
                        $hero_post_image = (get_the_post_thumbnail_url($brighter_blog_post_id, 'large')) ? get_the_post_thumbnail_url($brighter_blog_post_id, 'large') : get_template_directory_uri() . '/assets/images/no-image.jpg';
                        $brighter_blog_post_thumbnail_id = get_post_thumbnail_id(get_the_ID());
                        if (get_the_post_thumbnail_url()) {
                            $brighter_blog_hero_post_image_alt_text = get_post_meta($brighter_blog_post_thumbnail_id, '_wp_attachment_image_alt', true);
                        } else {
                            $brighter_blog_hero_post_image_alt_text = 'No Image';
                        }
                        if (strlen(get_the_title()) > 5) {
                            // Trim to the first 5 characters and add ellipsis
                            $hero_post_title = substr(get_the_title(), 0, 35) . '...';
                        } else {
                            // If the title is less than or equal to 5 characters, display it as is
                            $hero_post_title = get_the_title();
                        }
                        ?>
                        <div class="post-preview mb-3">
                            <div class="post-preview__image col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 position-relative">
                               
                            <?php
                                $brighter_blog_post_format = get_post_format();
                                
                                if ($brighter_blog_post_format == 'gallery') {
                                    // Assuming you have a custom field or a method to get the gallery image URL
                                    $gallery_url = get_post_meta(get_the_ID(), 'image_gallery', true); // Replace with your method
                                    $image_urls_array = explode(',', $gallery_url);
                                    foreach ($image_urls_array as $urlItem) {
                                        ?>
                                        <a href="<?php echo esc_url($urlItem); ?>" class="popup-image icon-btn play-btn style10">
                                            <i class="far fa-images"></i>
                                        </a>
                                        <?php
                                    }

                                } elseif ($brighter_blog_post_format == 'video') {
                                    // Assuming you have a custom field or a method to get the video URL
                                    $brighter_blog_video_url = get_post_meta(get_the_ID(), 'video_url', true); // Replace with your method
                                    ?>
                                    <a href="<?php echo esc_url($brighter_blog_video_url); ?>" class="style3 popup-video play-btn style10">
                                        <i class="fas fa-play"></i>
                                    </a>
                                    <?php
                                } elseif ($brighter_blog_post_format == 'image') {
                                    // Assuming you have a custom field or a method to get the image URL
                                    $image_url = get_post_meta(get_the_ID(), 'image_url', true); // Replace with your method
                                    ?>
                                    <a href="<?php echo esc_url($image_url); ?>" class="style3 popup-image play-btn style10">
                                        <i class="far fa-image"></i>
                                    </a>
                                    <?php
                                } elseif ($brighter_blog_post_format == 'audio') {
                                    // Assuming you have a custom field or a method to get the audio URL
                                    $audio_url = get_post_meta(get_the_ID(), 'audio_url', true); // Replace with your method
                                    ?>
                                    <a href="<?php echo esc_url($audio_url); ?>" class="style3 popup-audio play-btn style10">
                                        <i class="fa fa-headphones"></i>
                                    </a>
                                    <?php
                                } elseif ($brighter_blog_post_format == 'quote') {
                                    // Assuming you have a custom field or a method to get the audio URL
                                    $quote_url = get_post_meta(get_the_ID(), 'quote_url', true); // Replace with your method
                                    ?>
                                    <a href="<?php echo esc_url($quote_url); ?>" class="style3 popup-quote play-btn style10">
                                        <i class="fas fa-quote-right"></i>
                                    </a>
                                    <?php
                                } elseif ($brighter_blog_post_format == 'link') {
                                    // Assuming you have a custom field or a method to get the audio URL
                                    $link_url = get_post_meta(get_the_ID(), 'link_url', true); // Replace with your method
                                    ?>
                                    <a href="<?php echo esc_url($link_url); ?>" class="style3 popup-link play-btn style10">
                                        <i class="fas fa-link"></i>
                                    </a>
                                    <?php
                                } 
                                ?>
                                <img src="<?php echo esc_url($hero_post_image); ?>" alt="<?php echo esc_attr($brighter_blog_hero_post_image_alt_text); ?>">
                            </div>
                            <div class="post-preview__content col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                                <?php if (!empty($post_categories)) : ?>
                                    <div class="post-category">
                                        <?php echo esc_html($post_categories[0]->name); ?>
                                    </div>
                                <?php endif; ?>
                                <h2 class="post-title hero-post-title"> <a href="<?php echo esc_url(get_the_permalink()); ?>"><?php echo esc_html($hero_post_title); ?></a></h2>
                                <p class="post-excerpt"><?php echo esc_html($post_excerpt); ?></p>
                                <div class="post-meta">
                                    <div class="post-author">
                                        <img src="<?php echo esc_url($post_author_avatar); ?>" alt="<?php echo esc_attr($post_author_name); ?>" class="author-avatar">
                                        <span><?php echo esc_html('by '); ?> <?php echo esc_html($post_author_name); ?></span>
                                    </div>
                                </div>
                                <div class="extra-div">
                                    <?php $button_text = get_theme_mod('hero_post_btn_text', 'Discover More')?>
                                    <a href="<?php echo esc_url(get_permalink()); ?>" class="post-button"><?php echo esc_html($button_text); ?></a>
                                    <div class="post-date"><?php echo esc_html($post_date); ?></div>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    wp_reset_postdata();
                    ?>
                </div>
        </div>
        <?php
    } 
endif;

?>
