<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Brighter_Blog
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function brighter_blog_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter( 'body_class', 'brighter_blog_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function brighter_blog_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'brighter_blog_pingback_header' );


/** 
 *  Fallback for primary navigation.
 */
if( ! function_exists( 'brighter_blog_primary_navigation_fallback' ) ) :

	/**
	 * Fallback for primary navigation.
	 *
	 * @since 1.0.0
	 */
	function brighter_blog_primary_navigation_fallback() {
        ?>
		<ul>
			<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html__( 'Home', 'brighter-blog' ); ?></a></li>
            <?php
			wp_list_pages( array(
			'title_li' => '',
			'depth'    => 1,
			'number'   => 5,
			) );
            ?>
		</ul>
        <?php
	}
endif;



// get letest post function 

function brighter_blog_get_latest_posts() {
    $brighter_blog_posts_per_page = 10; // Define the number of posts per page
    $brighter_blog_page = 1;
    $brighter_blog_all_posts = array();

    do {
        $brighter_blog_args = array(
            'posts_per_page' => $brighter_blog_posts_per_page,
            'paged'          => $brighter_blog_page,
            'post_type'      => 'post'
        );
        $brighter_blog_query = new WP_Query($brighter_blog_args);
        $brighter_blog_posts = $brighter_blog_query->posts;

        if (!empty($brighter_blog_posts)) {
            $brighter_blog_all_posts = array_merge($brighter_blog_all_posts, $brighter_blog_posts);
        }

        $brighter_blog_page++;
    } while (!empty($brighter_blog_posts));

    $brighter_blog_choices = array();
    foreach ($brighter_blog_all_posts as $brighter_blog_post) {
        $brighter_blog_choices[$brighter_blog_post->ID] = get_the_title($brighter_blog_post->ID);
    }

    return $brighter_blog_choices;
}


/**
 * Brighter Blog Theme Purchase Link
 */

 if ( ! function_exists( 'brighter_blog_purchase_url' ) ) {
    function brighter_blog_purchase_url() {
        $brighter_blog_theme_purchase = 'https://checkout.freemius.com/plugin/17755/plan/29511/';
        $description = sprintf(
            __( 'Purchase the Pro Version for More Features. <a href="%s" target="_blank" class="Purchase-links">Purchase Now</a>', 'brighter-blog' ),
            esc_url( $brighter_blog_theme_purchase )
        );
        return $description;
    }
}
/**
 * Brighter Blog Theme Purchase Link
 */

 if ( ! function_exists( 'brighter_blog_purchase_link' ) ) {
    function brighter_blog_purchase_link() {
        $brighter_blog_purchase = 'https://checkout.freemius.com/plugin/17755/plan/29511/';
        return $brighter_blog_purchase;
    }
}


function brighter_blog_admin_notice() {
    // Check if the notification should be hidden
    $hide_notice = isset($_COOKIE['brighter_blog_admin_notice']) ? intval($_COOKIE['brighter_blog_admin_notice']) : 0;
    $brighter_blog_ads_banner_img = get_template_directory_uri() . '/assets/images/ads/upgrade-pro.jpg';
    
    // Get current admin page URL
    $current_screen = get_current_screen();
    $brighter_blog_ad_url = home_url() . '/wp-admin/admin.php?page=brighter-blog-addons';
    
    // Check if we are on the 'brighter-blog-addons' page
    $is_brighter_blog_addons_page = isset($_GET['page']) && $_GET['page'] === 'brighter-blog-addons';

    if (!$hide_notice && !$is_brighter_blog_addons_page) {
        ?>
        <div id="brighter-blog-admin-notice" class="notice is-dismissible">
            <br>
            <a href="<?php echo esc_url($brighter_blog_ad_url); ?>">
                <img src="<?php echo esc_url($brighter_blog_ads_banner_img); ?>" width="100%" alt="Brighter Blog">
            </a>
            <br>
        </div>
        <?php
    }
}


if (!class_exists('Brighter_Blog_Pro')) {
    add_action('admin_notices', 'brighter_blog_admin_notice');
    add_action('admin_footer', 'brighter_blog_admin_notice_script');
}

function brighter_blog_admin_notice_script() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $('#brighter-blog-admin-notice').on('click', '.notice-dismiss', function() {
                // Set a cookie to hide the notice for 3 days
                var date = new Date();
                date.setTime(date.getTime() + (3 * 24 * 60 * 60 * 1000));// 3 days in milliseconds
                document.cookie = "brighter_blog_admin_notice=1; expires=" + date.toUTCString() + "; path=/";
            });
        });
    </script>
    <?php
}

/**
 * Delete the `Hello world!` post after successful demo import.
 */
function ocdi_before_content_import( $selected_import ) {
    $post = get_page_by_path('hello-world', OBJECT, 'post');
    if ($post) {
        wp_delete_post($post->ID,true);
    }
}
add_action( 'ocdi/before_content_import', 'ocdi_before_content_import' );




/**
 * Add span tag in archive list count number
 */
function brighter_blog_span_archive_count($brighter_blog_links)
{
    $brighter_blog_links = str_replace('</a>&nbsp;(', '</a> <span class="post-count-number">(', $brighter_blog_links);
    $brighter_blog_links = str_replace(')', ')</span>', $brighter_blog_links);
    return $brighter_blog_links;
}

add_filter('get_archives_link', 'brighter_blog_span_archive_count');

/**
 * Add span tag in category list count number
 */
function brighter_blog_span_category_count($brighter_blog_links)
{
    $brighter_blog_links = str_replace('</a> (', '</a> <span class="post-count-number">(', $brighter_blog_links);
    $brighter_blog_links = str_replace(')', ')</span>', $brighter_blog_links);
    return $brighter_blog_links;
}

add_filter('wp_list_categories', 'brighter_blog_span_category_count');



// author social media share code 
function brighter_blog_author_custom_social_media_share()
{
    global $post;
    $brighter_blog_author_social_post_url = urlencode(get_permalink($post->ID));
    $brighter_blog_author_social_post_title = urlencode(get_the_title($post->ID));

    $brighter_blog_author_social_post_url_fb = "https://www.facebook.com/sharer.php?u=".$brighter_blog_author_social_post_url;
    $brighter_blog_author_social_post_url_tw = "https://twitter.com/share?url=".$brighter_blog_author_social_post_url."&text="
        .$brighter_blog_author_social_post_title;
    $brighter_blog_author_social_post_url_in = "https://www.linkedin.com/shareArticle?mini=true&url="
        .$brighter_blog_author_social_post_url."&title=".$brighter_blog_author_social_post_title;
    $brighter_blog_author_social_post_url_insta = "https://www.instagram.com/?url=".$brighter_blog_author_social_post_url;

    ?>
    <div class="social-btn style3">
        <a href="<?php echo esc_url($brighter_blog_author_social_post_url_fb); ?>" target="_blank">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a href="<?php echo esc_url($brighter_blog_author_social_post_url_tw); ?>" target="_blank">
            <i class="fab fa-twitter"></i>
        </a>
        <a href="<?php echo esc_url($brighter_blog_author_social_post_url_in); ?>" target="_blank">
            <i class="fab fa-linkedin-in"></i>
        </a>
        <a href="<?php echo esc_url($brighter_blog_author_social_post_url_insta); ?>" target="_blank">
            <i class="fab fa-instagram"></i>
        </a>
    </div>
    <?php
}

function brighter_blog_custom_social_media_share()
{
    global $post;
    $brighter_blog_custom_social_media_post_url_no_author = urlencode(get_permalink($post->ID));
    $brighter_blog_custom_social_media_post_title_no_author = urlencode(get_the_title($post->ID));

    $brighter_blog_author_social_post_url_fb_no_author = "https://www.facebook.com/sharer.php?u="
        .$brighter_blog_custom_social_media_post_url_no_author;
    $brighter_blog_author_social_post_url_tw_no_author = "https://x.com/share?url="
        .$brighter_blog_custom_social_media_post_url_no_author."&text=".$brighter_blog_custom_social_media_post_title_no_author;
    $brighter_blog_author_social_post_url_in_no_author = "https://www.linkedin.com/shareArticle?mini=true&url="
        .$brighter_blog_custom_social_media_post_url_no_author."&title=".$brighter_blog_custom_social_media_post_title_no_author;
    $brighter_blog_author_social_post_url_vimeo_no_author = "https://vimeo.com?u="
        .$brighter_blog_custom_social_media_post_url_no_author;
    $brighter_blog_author_social_post_url_instagram_no_author = "https://www.instagram.com/?url="
        .$brighter_blog_custom_social_media_post_url_no_author;
    $brighter_blog_author_social_post_url_youtube_no_author = "https://www.youtube.com/share?url="
        .$brighter_blog_custom_social_media_post_url_no_author;
    

    ?>
    <div class="social-media-share">
        <ul>
        <li>
            <a href="<?php echo esc_url($brighter_blog_author_social_post_url_fb_no_author); ?>" target="_blank">
                <i class="fa-brands fa-facebook-f"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo esc_url($brighter_blog_author_social_post_url_tw_no_author); ?>" target="_blank">
                <i class="fa-brands fa-x-twitter"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo esc_url($brighter_blog_author_social_post_url_in_no_author); ?>" target="_blank">
                <i class="fa-brands fa-linkedin-in"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo esc_url($brighter_blog_author_social_post_url_vimeo_no_author); ?>" target="_blank">
                <i class="fa-brands fa-vimeo"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo esc_url($brighter_blog_author_social_post_url_instagram_no_author); ?>" target="_blank">
                <i class="fa-brands fa-instagram"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo esc_url($brighter_blog_author_social_post_url_youtube_no_author); ?>" target="_blank">
                <i class="fa-brands fa-youtube"></i>
            </a>
        </li>


        </ul>
    </div>
    <?php
}


add_action('admin_footer', 'brighter_blog_custom_post_format_script');

function brighter_blog_custom_post_format_script()
{
    ?>
    <script>
        jQuery(document).ready(function ($) {
            // Function to show/hide elements based on selected post format
            function showHideElements() {
                var selectedFormat = $('#post-format-select').val(); // Get selected post format
                // Show or hide elements based on selected format
                if (selectedFormat == 'video') {
                    $('.video-fields').show(); // Show video fields
                    $('.brighter-blog-image-gallery-fields').hide(); // Hide image gallery fields
                } else if (selectedFormat == 'gallery') {
                    $('.video-fields').hide(); // Hide video fields
                    $('.brighter-blog-image-gallery-fields').show(); // Show image gallery fields
                } else {
                    $('.video-fields').hide(); // Hide video fields
                    $('.brighter-blog-image-gallery-fields').hide(); // Hide image gallery fields
                }
            }

            // Call the function initially to set the initial state
            showHideElements();

            // Call the function whenever the post format select option changes
            $('#post-format-select').on('change', function () {
                showHideElements();
            });
        });
    </script>
    <?php
}


// Add this code for custo woocommerce pagination.
remove_action('woocommerce_after_shop_loop', 'woocommerce_pagination', 10);
add_action('woocommerce_after_shop_loop', 'brighter_blog_custom_woocommerce_pagination', 10);

function brighter_blog_custom_woocommerce_pagination()
{
    // Use paginate_links() to generate pagination.
    $brighter_blog_paginate_links = paginate_links(array(
        'prev_text' => '<i class="fas fa-angle-double-left"></i>',
        'next_text' => '<i class="fas fa-angle-double-right"></i>',
        'type' => 'array', // Set type to array to customize the output.
    ));

    if ($brighter_blog_paginate_links) {
        ?>
        <div class="pagination">
            <ul>
                <?php
                foreach ($brighter_blog_paginate_links as $brighter_blog_item) {
                    echo '<li>' . $brighter_blog_item . '</li>';
                }
                ?>
            </ul>
        </div>
        <?php

    }
}


// Add custom select field to "Add New Category" form
add_action('category_add_form_fields', 'add_custom_icon_field_to_category');
function add_custom_icon_field_to_category() {
    ?>
    <div class="form-field">
        <label for="icon_for_category"><?php _e('Category Icon', 'brighter-blog'); ?></label>
        <select name="icon_for_category" id="icon_for_category">
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/default-category.svg'); ?>">
                <?php echo esc_html__('Default Icon', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/beauty.svg'); ?>">
                <?php echo esc_html__('Beauty', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/business.svg'); ?>">
                <?php echo esc_html__('Business', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/device.svg'); ?>">
                <?php echo esc_html__('Device', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/eco-tech.svg'); ?>">
                <?php echo esc_html__('Eco Tech', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/entertainment.svg'); ?>">
                <?php echo esc_html__('Entertainment', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/food.svg'); ?>">
                <?php echo esc_html__('Food', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/games.svg'); ?>">
                <?php echo esc_html__('Games', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/garden-uutdoor-spaces.svg'); ?>">
                <?php echo esc_html__('Garden Utdoor', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/health.svg'); ?>">
                <?php echo esc_html__('Health', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/home-tech-gadgets.svg'); ?>">
                <?php echo esc_html__('Home Tech Gadgets', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/hosting.svg'); ?>">
                <?php echo esc_html__('Hosting', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/makeup.svg'); ?>">
                <?php echo esc_html__('Makeup', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/management.svg'); ?>">
                <?php echo esc_html__('Management', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/music.svg'); ?>">
                <?php echo esc_html__('Music', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/news.svg'); ?>">
                <?php echo esc_html__('News', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/planet-earth.svg'); ?>">
                <?php echo esc_html__('Planet Earth', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/politics.svg'); ?>">
                <?php echo esc_html__('Politics', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/religions.svg'); ?>">
                <?php echo esc_html__('Religions', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/sports.svg'); ?>">
                <?php echo esc_html__('Sports', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/startups.svg'); ?>">
                <?php echo esc_html__('Startups', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/stress-free-living.svg'); ?>">
                <?php echo esc_html__('Stress Free Living', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/technology.svg'); ?>">
                <?php echo esc_html__('Technology', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/travel.svg'); ?>">
                <?php echo esc_html__('Travel', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/trends.svg'); ?>">
                <?php echo esc_html__('Trends', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/video.svg'); ?>">
                <?php echo esc_html__('Video', 'brighter-blog'); ?>
            </option>
            <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/yoga-meditation.svg'); ?>">
                <?php echo esc_html__('Yoga Meditation', 'brighter-blog'); ?>
            </option>
        </select>

        <div id="icon-preview" style="margin-top: 10px;">
            <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/default-category.svg'); ?>" 
                 alt="<?php esc_attr_e('Selected Icon Preview', 'brighter-blog'); ?>" 
                 id="selected-icon" 
                 style="width: 30px; height: 30px;">
        </div>

        <p class="description"><?php _e('Choose an icon for this category.', 'brighter-blog'); ?></p>
    </div>
    <?php
}

// Add custom select field to "Edit Category" form
add_action('category_edit_form_fields', 'edit_custom_icon_field_in_category');
function edit_custom_icon_field_in_category($term) {
    $selected_value = get_term_meta($term->term_id, 'icon_for_category', true);
    ?>
    <tr class="form-field">
        <th scope="row">
            <label for="icon_for_category"><?php _e('Category Icon', 'brighter-blog'); ?></label>
        </th>
        <td>
            <select name="icon_for_category" id="icon_for_category">
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/default-category.svg'); ?>"
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/default-category.svg')); ?>>
                    <?php echo esc_html__('Default Icon', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/beauty.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/beauty.svg')); ?>>
                    <?php echo esc_html__('Beauty', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/business.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/business.svg')); ?>>
                    <?php echo esc_html__('Business', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/device.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/device.svg')); ?>>
                    <?php echo esc_html__('Device', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/eco-tech.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/eco-tech.svg')); ?>>
                    <?php echo esc_html__('Eco Tech', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/entertainment.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/entertainment.svg')); ?>>
                    <?php echo esc_html__('Entertainment', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/food.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/food.svg')); ?>>
                    <?php echo esc_html__('Food', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/games.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/games.svg')); ?>>
                    <?php echo esc_html__('Games', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/garden-uutdoor-spaces.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/garden-uutdoor-spaces.svg')); ?>>
                    <?php echo esc_html__('Garden Outdoor Spaces', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/health.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/health.svg')); ?>>
                    <?php echo esc_html__('Health', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/home-tech-gadgets.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/home-tech-gadgets.svg')); ?>>
                    <?php echo esc_html__('Home Tech Gadgets', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/hosting.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/hosting.svg')); ?>>
                    <?php echo esc_html__('Hosting', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/makeup.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/makeup.svg')); ?>>
                    <?php echo esc_html__('Makeup', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/management.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/management.svg')); ?>>
                    <?php echo esc_html__('Management', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/music.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/music.svg')); ?>>
                    <?php echo esc_html__('Music', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/news.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/news.svg')); ?>>
                    <?php echo esc_html__('News', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/planet-earth.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/planet-earth.svg')); ?>>
                    <?php echo esc_html__('Planet Earth', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/politics.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/politics.svg')); ?>>
                    <?php echo esc_html__('Politics', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/religions.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/religions.svg')); ?>>
                    <?php echo esc_html__('Religions', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/sports.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/sports.svg')); ?>>
                    <?php echo esc_html__('Sports', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/startups.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/startups.svg')); ?>>
                    <?php echo esc_html__('Startups', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/stress-free-living.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/stress-free-living.svg')); ?>>
                    <?php echo esc_html__('Stress Free Living', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/technology.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/technology.svg')); ?>>
                    <?php echo esc_html__('Technology', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/travel.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/travel.svg')); ?>>
                    <?php echo esc_html__('Travel', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/trends.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/trends.svg')); ?>>
                    <?php echo esc_html__('Trends', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/video.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/video.svg')); ?>>
                    <?php echo esc_html__('Video', 'brighter-blog'); ?>
                </option>
                <option value="<?php echo esc_url(get_template_directory_uri() . '/assets/images/category-icon/yoga-meditation.svg'); ?>" 
                    <?php selected($selected_value, esc_url(get_template_directory_uri() . '/assets/images/category-icon/yoga-meditation.svg')); ?>>
                    <?php echo esc_html__('Yoga Meditation', 'brighter-blog'); ?>
                </option>

            </select>

            <div id="icon-preview" style="margin-top: 10px;">
                <?php
                    if (!empty($selected_value)){
                        $brighter_blog_category_icon = $selected_value;
                    }
                    else{
                        $brighter_blog_category_icon = get_template_directory_uri() . '/assets/images/category-icon/default-category.svg';
                    }
                ?>

                <img src="<?php echo esc_url($brighter_blog_category_icon); ?>" alt="Selected Icon Preview" id="selected-icon"  style="width: 30px; height: 30px;">
            </div>
            <p class="description"><?php _e('Choose an icon for this category.', 'brighter-blog'); ?></p>
        </td>
    </tr>
    <?php
}

// Save the custom select field value when adding or editing a category
add_action('created_category', 'save_custom_icon_field_in_category');
add_action('edited_category', 'save_custom_icon_field_in_category');
function save_custom_icon_field_in_category($term_id) {
    if (isset($_POST['icon_for_category'])) {
        update_term_meta($term_id, 'icon_for_category', esc_url_raw($_POST['icon_for_category']));
    }
}

