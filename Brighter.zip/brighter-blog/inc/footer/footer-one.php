</div>
<?php 
$brighter_blog_footer = get_theme_mod('footer_enable', 'on');
$brighter_blog_footer_hide_show = '';
if ($brighter_blog_footer == 'on') {
    $brighter_blog_footer_hide_show= 'brighter-blog-footer-show';
}
else{
    $brighter_blog_footer_hide_show= 'brighter-blog-footer-hide';
}
?>
<footer id="colophon" class="site-footer footer-wrapper footer-typography-settings footer-layout1 overflow-hidden <?php echo esc_attr($brighter_blog_footer_hide_show); ?>" >
    <?php if( is_active_sidebar( 'footer-one' ) || is_active_sidebar( 'footer-two' ) || is_active_sidebar( 'footer-three' ) || is_active_sidebar( 'footer-four' ) ) : ?>
    <div class="container">
        <div class="widget-area partial-refresh-footer">
            <div class="row justify-content-between">

                <?php if ( is_active_sidebar( 'footer-one' ) ) : ?>
                    <div class="col-md-3 col-xl-3 col-lg-3 text-color-changer">
                        <?php dynamic_sidebar( 'footer-one' ); ?>
                    </div>
                <?php endif; ?>


                <?php if ( is_active_sidebar( 'footer-two' ) ) : ?>
                    <div class="col-md-3 col-xl-3 col-lg-3 text-color-changer">
                        <?php dynamic_sidebar( 'footer-two' ); ?>
                    </div>
                <?php endif; ?>


                <?php if ( is_active_sidebar( 'footer-three' ) ) : ?>
                    <div class="col-md-3 col-xl-3 col-lg-3 text-color-changer">
                        <?php dynamic_sidebar( 'footer-three' ); ?>
                    </div>
                <?php endif; ?>


                <?php if ( is_active_sidebar( 'footer-four' ) ) : ?>
                    <div class="col-md-3 col-xl-3 col-lg-3 text-color-changer">
                        <?php dynamic_sidebar( 'footer-four' ); ?>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php
        // footer bottom
        require_once BRIGHTER_BLOG_INC_DIR . 'footer/footer-bottom/footer-bottom-one.php';// phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
    ?>
</footer>

