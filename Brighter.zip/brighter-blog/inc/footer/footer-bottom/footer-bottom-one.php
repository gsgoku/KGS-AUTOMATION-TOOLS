<div class="copyright-wrap">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-auto align-self-center">
                <p class="copyright-text text-center">
                    <?php
                        $brighter_blog_powered_by =  sprintf( esc_html__( '| Brighter-Blog Theme by %s', 'brighter-blog' ),
                            '<a target="_blank" rel="dofollow" href="'. esc_url( 'https://mycodecare.com/brighter' ) .'">MyCodeCare</a>' );
                        $brighter_blog_copyright = get_theme_mod( 'copyright_setting', 'Proudly powered by WordPress ');
                        $brighter_blog_copyright = str_replace('[Y]', date("Y"), $brighter_blog_copyright);
                        echo esc_html($brighter_blog_copyright);

						$powerby_hide_show_control = get_theme_mod('powerby_hide_show_control' , 'on');
						if($powerby_hide_show_control == 'on'){
                        echo wp_kses_post( $brighter_blog_powered_by );
						}
                    ?>
                </p>
            </div>
        </div>
    </div>
</div>