<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Brighter_Blog
 */
?>
    <!doctype html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php wp_head(); ?>
    </head>
<?php
$body_typography = get_theme_mod('body_typography', array('font-family' => 'Kumbh Sans'));
if (is_array($body_typography) && isset($body_typography['font-family'])) {
    $font_family = esc_attr($body_typography['font-family']);
} else {
    $font_family = 'Kumbh Sans'; // Provide a default font family if not set
}
$brighter_blog_body_font = 'font-family:' . esc_attr($font_family);
?>
<body <?php body_class(); ?> style="<?php echo esc_attr($brighter_blog_body_font); ?>">
<?php
$brighter_blog_loder_enable_disable = get_theme_mod('preloader_options', 'off');
if ($brighter_blog_loder_enable_disable == 'on') {
    ?>
    <div class="preloader ">
        <div class="preloader-inner">
            <span class="loader"></span>
        </div>
    </div>
    <?php
}
?>
    <!-- Preloader code  Ends-->
    <!-- subscribs popup start  -->
<?php
$brighter_blog_popup_subscribe_enable_disable = get_theme_mod('popup_subscribe_options', 'off');
if ($brighter_blog_popup_subscribe_enable_disable == 'on') {
    $brighter_blog_popup_form_title = get_theme_mod('popup_subscribe_form_title', 'Subscribe');
    $brighter_blog_popup_form_text = get_theme_mod('popup_subscribe_form_text', 'Sign up to get update about us. Dont be hasitate your email is safe.');
    $brighter_blog_popup_form_check_box_text = get_theme_mod('popup_subscribe_form_checkbox_text', 'I dont want to see this popup again.');
    $popup_newsletter_shortcode = get_theme_mod('popup_newsletter_shortcode', '');
    ?>
    <div class="popup-subscribe-area">
        <div class="container">
            <div class="popup-subscribe">
                <div class="box-content">
                    <button class="simple-icon popupClose"><i class="fas fa-times"></i></button>
                    <div class="widget newsletter-widget footer-widget">
                        <h3 class="widget_title"><?php echo esc_html($brighter_blog_popup_form_title) ?></h3>
                        <p class="footer-text"><?php echo esc_html($brighter_blog_popup_form_text) ?></p>
                        <?php
                        echo(do_shortcode($popup_newsletter_shortcode));
                        ?>
                        <div class="mt-30">
                            <input type="checkbox" id="destroyPopup">
                            <label for="destroyPopup"><?php echo esc_html($brighter_blog_popup_form_check_box_text) ?></label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php } ?>
<?php wp_body_open(); ?>
<div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e('Skip to content', 'brighter-blog'); ?></a>
<?php
get_template_part('inc/header/header-' . get_theme_mod('select_header', 'one'));