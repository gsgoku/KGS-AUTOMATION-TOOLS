<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Brighter_Blog
 */
get_header();
?>
    <main id="primary" class="site-main">
        <div class="container">
            <section class="error-404 not-found">
                <!-- .page-header -->
                <div class="page-content">
                    <div class="container">
                        <div class="row">
                            <?php
                            $search_layout_option = get_theme_mod('error_layout', 'rtl');
                            ?>
                            <?php if (is_active_sidebar('sidebar-1') && $search_layout_option == 'ltl') : ?>
                                <?php if (is_active_sidebar('sidebar-1')) : ?>
                                    <div class="col-xxl-4 col-lg-5 sidebar-widget-area">
                                        <?php dynamic_sidebar('sidebar-1'); ?>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if ($search_layout_option == 'no-sidebar'): ?>
                            <div class="col-12">
                                <?php else: ?>
                                <div class="col-xxl-8 col-lg-7">
                                    <?php endif; ?>
                                    <header class="page-header">
                                        <h2 class="page-title"><?php esc_html_e('Oops! That page can&rsquo;t be found.', 'brighter-blog'); ?></h2>
                                    </header>
                                    <div class="space-bottom">
                                        <div class="container">
                                            <div class="row justify-content-center">
                                                <div class="col-xl-10">
                                                    <div class="error-wrap text-center">
                                                        <h2 class="error-title"><?php esc_html_e('Oops!', 'brighter-blog'); ?></h2>
                                                        <h3 class="error-subtitle"><?php esc_html_e('Something went wrong', 'brighter-blog'); ?></h3>
                                                        <img src='<?php echo esc_url(get_template_directory_uri() . '/assets/images/error.svg'); ?>'
                                                        alt='Error Image'>
                                                        <p>
                                                            <?php esc_html_e('It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'brighter-blog'); ?>
                                                        </p>
                                                        <?php get_search_form(['form_type' => 'newsletter']); ?>
                                                        <div class="btn-wrap justify-content-center mt-60">
                                                            <a class="btn" href="<?php echo esc_url(home_url()); ?>">
                                                                <?php esc_html_e('Back to home', 'brighter-blog'); ?>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if (is_active_sidebar('sidebar-1') && $search_layout_option == 'rtl') : ?>
                                    <?php if (is_active_sidebar('sidebar-1')) : ?>
                                        <div class="col-xxl-4 col-lg-5 sidebar-widget-area">
                                            <?php dynamic_sidebar('sidebar-1'); ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- .page-content -->
            </section><!-- .error-404 -->
        </div>
    </main><!-- #main -->

<?php
get_footer();
