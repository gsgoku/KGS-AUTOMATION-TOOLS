# Gdrive-File-to-Direct-Link
Your google drive file to direct link (GitHub release)
```
- Warning!!!
- you can only use this tool for files with Size of less than 2048MB (2GB)
- Maximum Size (2048MB) limited by GitHub!!!
```


# how to use this???

1) fork this repo

2) click on "Actions"

3) click on "Gdrive-file-to-link" (on left side)

4) click on "Run workflow" (on right side)

5) Paste your Google drive file link

(Example: https://drive.google.com/file/d/1g8DVDAzv_qnshNMK7V8WByWJRqi5ekTw/view?usp=sharing)

6) click on "Run workflow"


You can see or download the file from [Release](../../releases)
